<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->

<?php
include_once('./helpers/session.php');
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekrut.Saya - Dashboard</title>

    <link rel='shortcut icon' type='image/x-icon' href='./assets/img/favicon.png' />

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="./assets/css/style.css">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/91e6fc2cdf.js" crossorigin="anonymous"></script>

    <script src="./javascript/DashboardPage.js"></script>
</head>

<body>

    <?php
    include_once('./components/header.php');
    ?>


    <!-- Dashboard Page Content-->
    <div class="content container-fluid mb-4">
        <div>
            <i class="fas fa-user-circle mt-5" style="font-size: 100px; margin-left: 100px; color: #0e79b2; float: left;"></i>
            <div class="profile mt-5 ml-4" style="display: inline-block;">
                <span class="align-self-center" style="color: #0e79b2; font-size: 30px;"><?php echo $_SESSION['username'] ?></span><br>
                <a href="./UserProfile.php?id=<?php echo $_SESSION['user_id'] ?>" id="edit_profile" style="text-decoration: none;  color: white;"><span class="pelamar" style="background-color: #f49e4c;">Ubah Profile</span></a>
            </div>
            <div class="d-flex justify-content-end">
                <a href="JobDetail.php?id=1" id="add_job" style="text-decoration: none; color: white;margin-top: -25px; margin-right: 100px;"><span class="pelamar" style="background-color: #f49e4c;">Cari Pekerjaan</span></a>
            </div>
        </div>

        <div class="jobs container mt-5">
            <h2 class="mb-2 mt-2" style="color: #0e79b2; font-weight: bold;">Daftar pekerjaan yang sudah dilamar</h2>
            <table class="table table-striped table-bordered text-center">
                <thead>
                    <tr style="background-color: #0e79b2;">
                        <td scope="col">No</td>
                        <td scope="col">Nama Pekerjaan</td>
                        <td scope="col">Tanggal Pengajuan</td>
                        <td scope="col">Status</td>
                    </tr>
                </thead>
                <tbody id="table_body">
                </tbody>
            </table>
            <table id="table_template">
                <tr class="job_info">
                    <th scope="row" style="vertical-align: middle;" id="iRow"></th>
                    <td style="vertical-align: middle;" id="iJobName"></td>
                    <td style="vertical-align: middle;" id="iDate"></td>
                    <td style="vertical-align: middle" id="iStatus"></td>
                </tr>
                <tr class="empty" style="display: none">
                </tr>
            </table>
        </div>
    </div>

    <?php
    include_once('./components/footer.php');
    ?>

</body>

</html>