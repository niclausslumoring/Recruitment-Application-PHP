<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->

<?php
include_once('./helpers/session.php');
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Rekrut.Saya - Dashboard</title>

  <link rel="stylesheet" href="./assets/css/FaqPage.css">

  <link rel='shortcut icon' type='image/x-icon' href='./assets/img/favicon.png' />

  <!-- Self Style by Muhammad Wira -->
  <link rel="stylesheet" href="../../style/style.css">

  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <!-- Popper JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

  <script src="https://kit.fontawesome.com/91e6fc2cdf.js" crossorigin="anonymous"></script>
</head>

<body>

  <!-- Navbar -->
  <?php
  include_once('./components/header.php');
  ?>


  <div>
    <div class="jumbotron text-center">
      <span class="Judul1">Forum Pertanyaan</span>
      <br><br>
      <p>Anda bisa mengajukan pertanyaan dengan mengisi form di bawah ini</p>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-sm-4" id="kirim_pertanyaan">
          <span class="Judul2">Kirim Pertanyaan</span>
          <br>
          <form id="login-form" class="form" action="" method="post">
            <div class="form-group">
              <input type="text" name="email" id="email" class="form-control" placeholder="E-mail anda">


              <input type="text" name="username" id="username" class="form-control" placeholder="Nama">
              <select id="pertanyaan_start" name="pertanyaan_start" />
              <option>Kategori Pertanyaan</option>
              <option>Suggestion</option>
              <option>Problem</option>
              <option>Thanks</option>

              <textarea id="question" placeholder="Masukan pertanyaan anda di sini" rows="4" cols="46" name="comment" form="usrform"></textarea>

              <input type="submit" name="submit" class="btn btn-info btn-md" value="Submit">
            </div>
          </form>
        </div>
        <div class="col-sm-4">
          <span class="Judul2">Informasi Kontak</span>
          <div>
            <div class="row">
              <div class="col-md-6">
                <h5>ADDRESS</h3>
                  <p>Jl KH. Syahdan, Jakarta</p>
              </div>
              <div class="col-md-6">
                <h5>PHONE</h5>
                <p>(+62)8 1234 567 891</p>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <h5>EMAIL</h5>
                <p>rekruitsaya@gmail.com</p>
              </div>
              <div class="col-md-6">
                <h5>FAX</h5>
                <p>021-7539153</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Footer -->

  <?php
  include_once('./components/footer.php');
  ?>



</body>

</html>