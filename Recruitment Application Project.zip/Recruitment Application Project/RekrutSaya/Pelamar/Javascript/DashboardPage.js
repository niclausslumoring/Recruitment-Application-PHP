function loadApplicants() {
    $.ajax({
        url: './controllers/doLoadApplicants.php',
        method: 'GET',
        data: { 'applicant': 1 },
        success: function(data) {
            console.log(data);
            if (data == 'no data') {
                var template = $('.empty').clone().show();
                $('#table_body').append(template);
                $('.empty').append('<td class="empty" colspan="4">Belum ada lamaran</td>');
            } else {
                var job = JSON.parse(data);
                var counter = 0;
                while (counter < job.length) {
                    var template = $('.job_info', '#table_template').clone().removeClass('.job_info').attr('id', job[counter].ID).data("job", job[counter]).show();
                    var date = convertDate(job[counter]);
                    $('#iRow', template).text(counter + 1);
                    $('#iJobName', template).text(job[counter].JobName);
                    $('#iDate', template).text(date);
                    if (job[counter].Status == "") $status = "Sedang diproses perusahaan";
                    else {
                        if (job[counter].Status == 'Accept')
                            $status = 'Diterima';
                        else $status = 'Ditolak'
                    }
                    $('#iStatus', template).text($status);
                    console.log(job[counter].ID);
                    $('#table_body').append(template);
                    // changeStatus(job[counter].ID);

                    counter++;
                }

            }
        }
    })
}

function convertDate(x) {
    var date = new Date(x.Date);
    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    var day = date.getDate();
    var month = monthNames[date.getMonth()];
    var year = date.getFullYear();
    return String(day + ' ' + month + ' ' + year);
}

$(document).ready(function() {
    loadApplicants();
})