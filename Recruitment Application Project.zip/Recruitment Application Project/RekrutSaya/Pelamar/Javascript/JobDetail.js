var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};

function loadJob(id) {
    $.ajax({
        url: 'controllers/doLoadJob.php',
        method: 'GET',
        data: { 'job': 1, 'job_id': id },
        success: function(data) {
            console.log(data);
            if (data == 'no data') {

            } else {
                var job = JSON.parse(data);
                var counter = 0;
                while (counter < job.length) {
                    console.log(job[counter].ProfilePictureAddress);
                    var tes;
                    var template = $('#job_info').clone().data("job", job[counter]).show();
                    if (job[counter].ProfilePictureAddress) {
                        tes = job[counter].ProfilePictureAddress.split("/");
                        $('#photo', template).attr("src", "../Perusahaan/" + tes[2] + "/" + tes[3] + "/" + tes[4]).attr('style', 'width: 100px;').show();
                    } else {
                        $tes = '../Perusahaan/assets/defaultComp.png';
                        $('#photo', template).attr("src", $tes).attr('style', 'width: 100px; margin-bottom: 20px;').show();
                    }
                    // var date = convertDate(job[counter]);

                    $('#iJobName', template).text(job[counter].JobName);
                    $('#iCompanyName', template).text(job[counter].CompanyName);
                    $('#iLocation', template).text(job[counter].Location);
                    $('#iJobDesc', template).text(job[counter].Description);
                    var require = job[counter].JobCondition.split(",");
                    console.log(require);
                    for (var i = 0; i < require.length; i++) {
                        $('#iJobRequire', template).append($.trim(require[i]));
                        $('#iJobRequire', template).append('<br>');
                    }
                    var facility = job[counter].Facility.split(",");
                    var facility_template = [];
                    if (facility == "") {
                        facility_template[0] = $('#iFacilityContent', template).clone().removeClass('col-md-1').addClass('col-lg').show();
                        $('#iFacilityName', facility_template[0]).text("Tidak ada fasilitas");
                    } else {
                        for (var i = 0; i < facility.length; i++) {
                            facility_template[i] = $('#iFacilityContent', template).clone().show();
                            var facility_src = "../Perusahaan/assets/Icon Tambahan/" + $.trim(facility[i]) + ".png";
                            $('#iFacility', facility_template[i]).attr("src", facility_src);
                            $('#iFacilityName', facility_template[i]).text(facility[i]);
                        }
                    }
                    var job_img_insert = $('#insert_img', template).clone().show();
                    var src_img = job[counter].Photo.split("/");
                    if (src_img == "") {
                        $('#iImgError', job_img_insert).text('Tidak ada foto');
                    } else {
                        $('#img_here', job_img_insert).attr('src', "../Perusahaan/" + src_img[2] + "/" + src_img[3] + "/" + src_img[4])
                    }
                    $('#insert_img_here', template).append(job_img_insert);
                    $('#insert_facility', template).append(facility_template);
                    $('#iCompDesc', template).text(job[counter].CompanyDesc);
                    console.log(job[counter].ID)
                    $('.insert').append(template);
                    // loadStatus(job[counter].ID);
                    // changeStatus(job[counter].ID);

                    counter++;
                }

            }
        }
    })
}

$(document).ready(function() {
    var id = getUrlParameter('id');

    loadJob(id);
    $('.cv').on('change', function(e) {
        var fileName = '';
        fileName = e.target.value.split('\\').pop();

        if (fileName)
            $('#cv_text').text(fileName);
    });

})