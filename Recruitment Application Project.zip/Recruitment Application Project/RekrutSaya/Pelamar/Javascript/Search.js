var template = $("#looptemplate .list-group").length;
console.log(template);
var limit = 10;

$("#looptemplate .list-group:gt(" + (limit - 1) + ")").hide();
$('.pagination').append("<li class='page-item active'><a class='page-link' href='#'>" + 1 + "</a></li>");
var totalpage = Math.round(template / limit);
for (var i = 1; i < totalpage; i++) {
    $('.pagination').append("<li class='page-item'><a class='page-link' href='#'>" + (i + 1) + "</a></li>");
}
$('.pagination').append("<li id='next_page'><a class='page-link' href='#' aria-label='Next'><span aria-hidden='true'>&raquo;</span><span class='sr-only'>Next</span></a></li>");

function loadJob(id) {
    $.ajax({
        url: 'controllers/doLoadJob.php',
        method: 'GET',
        data: { 'query': id },
        success: function(data) {
            console.log(data);
            if (data == 'no data') {

            } else {
                var job = JSON.parse(data);
                var counter = 0;
                while (counter < job.length) {
                    console.log(job[counter].ProfilePictureAddress);
                    var tes;
                    var template = $('#job_info').clone().data("job", job[counter]).show();
                    if (job[counter].ProfilePictureAddress) {
                        tes = job[counter].ProfilePictureAddress.split("/");
                        $('#photo', template).attr("src", "../Perusahaan/" + tes[2] + "/" + tes[3] + "/" + tes[4]).attr('style', 'width: 100px;').show();
                    } else {
                        $tes = '../Perusahaan/assets/defaultComp.png';
                        $('#photo', template).attr("src", $tes).attr('style', 'width: 100px; margin-bottom: 20px;').show();
                    }
                    // var date = convertDate(job[counter]);

                    $('#iJobName', template).text(job[counter].JobName);
                    $('#iCompanyName', template).text(job[counter].CompanyName);
                    $('#iLocation', template).text(job[counter].Location);
                    $('#iJobDesc', template).text(job[counter].Description);
                    $('.insert').append(template);
                    // loadStatus(job[counter].ID);
                    // changeStatus(job[counter].ID);

                    counter++;
                }

            }
        }
    })
}

$(document).ready(function() {
    // loadJob(x);
    $.ajax({
        url: '../Perusahaan/DBHelper/API/LoadSelect.php',
        method: 'GET',
        data: { 'type': 1 },
        success: function(data) {
            var type = JSON.parse(data);
            for (var i = 0; i < type.length; i++) {
                $('#job_type').append('<option value="' + type[i].ID + '">' + type[i].JobType + '</option>');
            }
        }
    })

    $.ajax({
        url: '../Perusahaan/DBHelper/API/LoadSelect.php',
        method: 'GET',
        data: { 'salary': 1 },
        success: function(data) {
            var type = JSON.parse(data);
            for (var i = 0; i < type.length; i++) {
                $('#salary').append('<option value="' + type[i].ID + '">' + type[i].salary + '</option>');
            }
        }
    })

    $.ajax({
        url: '../Perusahaan/DBHelper/API/LoadSelect.php',
        method: 'GET',
        data: { 'location': 1 },
        success: function(data) {
            var type = JSON.parse(data);
            for (var i = 0; i < type.length; i++) {
                $('#location').append('<option value="' + type[i].ID + '">' + type[i].Location + '</option>');
            }
        }
    })
})

$('.pagination li.page-item').on('click', function() {
    if ($(this).hasClass('active')) {
        return false;
    } else {
        var cur = $(this).index();
        $('.pagination li').removeClass('active');
        $('#looptemplate .list-group').hide();
        $(this).addClass('active');
        var total = limit * cur;
        for (var i = total - limit; i < total; i++) {
            $('#looptemplate .list-group:eq(' + i + ')').show();
        }
    }

})
$('#next_page').on('click', function() {
    var page = $('.pagination li.active').index();
    if (page === totalpage) {
        return false;
    } else {
        page++;
        $('.pagination li').removeClass('active');
        $('#looptemplate .list-group').hide();
        var total = limit * page;
        for (var i = total - limit; i < total; i++) {
            $('#looptemplate .list-group:eq(' + i + ')').show();
        }
        $('.pagination li.page-item:eq(' + (page - 1) + ')').addClass('active');


    }
})
$('#previous_page').on('click', function() {
    var page = $('.pagination li.active').index();
    if (page === 1) {
        return false;
    } else {
        page--;
        $('.pagination li').removeClass('active');
        $('#looptemplate .list-group').hide();
        var total = limit * page;
        for (var i = total - limit; i < total; i++) {
            $('#looptemplate .list-group:eq(' + i + ')').show();
        }
        $('.pagination li.page-item:eq(' + (page - 1) + ')').addClass('active');


    }
})

// alert(template);