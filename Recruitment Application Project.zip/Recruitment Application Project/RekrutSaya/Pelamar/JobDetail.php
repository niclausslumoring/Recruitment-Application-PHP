<!--
    Created by : Niclauss
    Date : 1 February 2020
-->

<?php
include_once('./helpers/session.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekrut.Saya - Lihat Pekerjaan</title>

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="JobDetail.css">

    <link rel="stylesheet" href="./assets/css/Upload.css">

    <link rel="stylesheet" href="./../Perusahaan/style/style.css">

    <link rel='shortcut icon' type='image/x-icon' href='./assets/img/favicon.png' />

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>

    <script src="Javascript/JobDetail.js"></script>

</head>

<body>
    <?php
    include_once('./components/header.php');
    ?>

    <br>

    <div class="mt-2" style="margin-left: 100px;">
        <a href="DashboardPage.php" id="back" style="text-decoration: none;  color: white;"><span class="pelamar" style="background-color: #0e79b2;">Kembali</span></a>
    </div>

    <br>
    <div class="insert container mb-5" style="border: 1px solid black">

    </div>
    <div id="job_info" style=" display: none">
        <div class="row" style="border-bottom: 1px solid grey">
            <div class="col-md-2 mt-3">
                <img style="margin-right:30px;" id="photo">
            </div>
            <div class="col-md-6" style="margin-left: -50px; margin-top: 20px">
                <h5 style="color: #0e79b2;" id="iJobName"></h5>
                <h6 id="iCompanyName"></h6>
                <h6 id="iLocation"></h6>
            </div>
            <div class="col-md-4 mt-4">
                <a data-toggle="modal" data-target="#myModal" class="btn btn-primary" role="button" aria-pressed="true" style="float:right; border-radius: 10px; background-color: #f49e4c;">Ajukan Sekarang</a>
            </div>
        </div>

        <div class="row text-center" style="background-color: #fafafa; border-bottom: 1px solid black">
            <div class="col-md mt-3 mb-3" style="background-color: white; margin-left: 50px">
                <h5 class="mt-2" style="color: #0e79b2;">Deskripsi Pekerjaan</h5>
                <div class="text-left ml-3 mr-3">
                    <h6 id="iJobDesc"></h6>
                </div>
            </div>
            <div class="col-1 mt-3 mb-3">

            </div>
            <div class="col-md mt-3 mb-3" style="background-color: white; margin-right: 50px">
                <h5 style="color: #f49e4c; " class="mt-2">Persyaratan Pelamar</h5>
                <div class="text-left ml-3 mr-3">
                    <h6 id="iJobRequire"></h6>
                </div>
            </div>
        </div>
        <div class="row mt-3 ml-5">
            <h5 style="color: #0e79b2;">Fasilitas</h5>
        </div>
        <div class="row" style="border-bottom: 1px solid black" id="insert_facility">
            <div class="col-md-1 mt-2 ml-5 text-center" id="iFacilityContent" style="display: none">
                <div class="row">
                    <img style="max-width: 100px" id="iFacility">
                </div>
                <div class="row text-center mb-3 mt-3">
                    <h6 id="iFacilityName"></h6>
                </div>
            </div>
        </div>
        <div class="row" style="background-color: #fafafa;">
            <h5 class="ml-5 mt-3" style="color: #0e79b2; background-color: #fafafa;">Lingkungan Kerja</h5>
        </div>
        <div class="row" style="background-color: #fafafa; border-bottom: 1px solid black" id="insert_img_here">
            <div class="col mt-3 ml-5 mb-5" style="background-color: #fafafa; display: none;" id="insert_img">
                <img style="width: 100px;" class="gambarLingkungan2" id="img_here">
                <h6 id="iImgError"></h6>
            </div>
        </div>

        <div class="row">
            <h5 class="ml-5 mt-3" style="color: #0e79b2;">Mengenai Perusahaan</h5>
        </div>
        <div class="row">
            <h6 class="mb-5 ml-5" id="iCompDesc"></h6>
        </div>

    </div>

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-lg">
            <?php
            include_once('./UserUpload.php');
            ?>

        </div>
    </div>

    <?php
    include_once('./components/footer.php');
    ?>
</body>

</html>