<?php
include_once 'helpers/session.php'
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Search</title>

    <link rel="stylesheet" href="Search.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>


</head>

<body>
    <?php
    include_once 'components/header.php'
    ?>


    <div id="navbar_header2">
        <nav class="navbar header2 container">
            <form action="controllers/doSetQuery.php" method="GET">
                <div class="row form-group">
                    <div class="col-lg-3 mr-5">
                        <i class="fas fa-search" aria-hidden="true"></i>
                        <input class="form-control form-control-sm ml-4" type="text" placeholder="Cari posisi, lokasi, dan jenis pekerjaan" aria-label="Search" style="margin-top: -25px">
                    
                            
                        
                    </div>
                    <div class="col-1">
                        <h6>Filter :</h6>
                    </div>
                    <div class="col-2">
                        <select class="form-control" name="job_type" id="job_type" required>
                            <option value="" style="display: none;">Tipe Pekerjaan*</option>
                        </select>
                    </div>
                    <div class="col-2">
                        <select class="form-control" name="location" id="location" required>
                            <option value="" style="display: none;">Lokasi*</option>
                        </select>
                    </div>
                    <div class="col-2">
                        <select class="form-control" name="salary" id="salary" required>
                            <option value="" style="display: none;">Gaji*</option>
                        </select>
                    </div>
                    <div class="col mt-2">
                        <button type="submit" name="submit" style="border: none"><span class="pelamar">Cari</span></button>
                    </div>
                </div>
            </form>

        </nav>
    </div>

    <?php if(isset($result)){
        while($row = $result->fetch_assoc()){

    ?>
    <div class="container mt-3">
        <div id="looptemplate" class="mb-3">
            <div class="list-group mt-3">
                <a href="" class="list-group-item" style="background-color: white; text-decoration: none;">
                    <div class="row">
                        <div class="col-md-2 mt-2">
                            <img src="assets/img/lowongan.png" style="margin-right:30px; width: 100px" id="photo">
                        </div>
                        <div class="col-md-9" style="margin-left: -50px; margin-top: 20px">
                            <h5 style="color: #0e79b2;" id="iJobName"><?php echo $row['j.JobName'] ?></h5>
                            <h6 id="iCompanyName" style="color: black"><?php echo $row['c.CompanyName'] ?></h6>
                        </div>
                        <div style="float: right">
                            <h6 id="iLocation" style="color: black"><?php echo $row['l.Location'] ?></h6>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-10">
                            <h6 id="iJobDesc" style="color: black"><?php echo $row['d.Description'] ?></h6>
                        </div>

                    </div>
                </a>
            </div>
        </div>

    <?php 
            }
        } 
    ?>

        <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center">
                <li id="previous_page">
                    <a class="page-link" href="#" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                        <span class="sr-only">Previous</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>


    <!-- <div id="lowongan_container">
        <div class="container">
            <div class="row kotakgede">
                <div class="col perusahaan1">
                    <img src="u444.svg" id="foto_perusahaan" alt="logo perusahaan">
                    <div id="data_perusahaan">
                        <span id="tipe_pekerjaan">Tipe Pekerjaan</span>
                        <div id="lokasi_container">
                            <span id="lokasi">Lokasi Barat</span>
                        </div>
                        <br>
                        <span id="nama_perusahaan">Nama Perusahaan</span>
                        <br>
                        <span id="deskripsi_perusahaan">Deskripsi aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</span>
                    </div>
                </div>
            </div>
        </div>

        <nav aria-label="Page navigation example">
            <ul class="pagination slide">
                <li class="page-item">
                    <a class="page-link" href="#" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                        <span class="sr-only">Previous</span>
                    </a>
                </li>
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item">
                    <a class="page-link" href="#" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                        <span class="sr-only">Next</span>
                    </a>
                </li>
            </ul>
        </nav>

    </div> -->

    <br>
    <br>


    <?php
    include_once 'components/footer.php';
    ?>
</body>
<script src="Javascript/Search.js"></script>

</html>