<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->

<?php 
    include_once('./helpers/session.php');
 ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ForgotPassword</title>

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="./assets/css/PelamarForgetPassword.css">

    <link rel='shortcut icon' type='image/x-icon' href='./assets/img/favicon.png' />

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
    <?php 
        include_once('./components/header.php');
     ?>


    <br>
    <br>
    <br>
   
    <center>
        <div class="card border-dark" style="max-width: 30rem;">
            <h3 class="card-header">Lupa kata sandi Anda ?</h3>
            <div class="card-body text-dark">
              
              <p class="card-text">Jangan khawatir. Anda hanya perlu memasukan alamat email anda sehingga kami dapat mengirimkan link untuk mengubah kata sandi</p>
              <div class="form-group">
                
                <span class="email">Email anda<span class="btg">*</span></span>
                <input type="text" name="username" id="username" class="form-control" placeholder="Contoh: test@gmail.com">
            </div>
                <hr>
                <a href="#" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">  Kirim  </a>
            </div>
          </div>
    </center>
   

      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
        
      
      
                
    <?php 
        include_once('./components/footer.php');
     ?>

</body>

</html>