<!DOCTYPE html>
<html lang="en">

<?php
include_once('./helpers/session.php');
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekrut.Saya - Login</title>

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="./assets/css/PelamarSignIn.css">

    <link rel='shortcut icon' type='image/x-icon' href='./assets/img/favicon.png' />

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
    <?php include('./components/header.php'); ?>

    <div id="login">
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="login-form" class="form" action="./controllers/doUserLogin.php" method="post">
                            <span class="Judul1"> Masuk Sebagai <span class="Judul2">Pelamar</span></span>
                            <hr>
                            <div class="form-group">
                                <input type="text" name="username" id="username" class="form-control" placeholder="Username">
                            </div>
                            <div class="form-group">

                                <input type="password" name="password" id="password" class="form-control" placeholder="Kata Sandi">
                            </div>
                            <div class="form-group">
                                <input id="remember-me" name="remember-me" type="checkbox"> <label for="remember-me" class="text-info"><span>Ingat Saya</span> <span></span></label><br>
                                <input type="submit" name="submit" class="btn btn-info btn-md" value="Masuk">
                            </div>
                            <div id="register-link" class="text-right">
                                <a href="./UserForgetPassword.php" class="text-info">Lupa Kata Sandi?</a>
                            </div>

                            <br>
                            <br>
                            <label id="lblError" style="color: red;">
                                <?php
                                if (isset($_SESSION['error'])) {
                                    echo $_SESSION['error'];
                                }
                                unset($_SESSION['error']);
                                ?>
                            </label>
                            <br>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br>
    <br>
    <br>
    <br>


    <?php
    include_once('./components/footer.php');
    ?>

</body>

</html>