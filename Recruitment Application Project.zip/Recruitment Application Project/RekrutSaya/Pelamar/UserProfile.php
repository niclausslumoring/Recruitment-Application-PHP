<!DOCTYPE html>
<html lang="en">

<?php 
    include_once('./helpers/session.php');
    include_once('./db/database.php');
 ?>



<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>EditProfile</title>

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="./assets/css/PelamarEditProfile.css">

    <link rel='shortcut icon' type='image/x-icon' href='./assets/img/favicon.png' />

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
    <?php 
        include_once('./components/header.php');
     ?>
     <?php 
        $id = $_GET['id'];
        $query = "SELECT * FROM users WHERE id=$id";
        $users = mysqli_query($connection, $query);

      ?>

    <br>
    <br>
    <br>    
    <div class="container">
        <h4 style="color: #0e79b2;">Edit Profile Anda</h4>
          <hr>
        <form class="form-horizontal" role="form" action="./controllers/doUserProfile.php" method="POST" enctype="multipart/form-data">
          <?php while($row = mysqli_fetch_assoc($users)){ ?>
        <div class="row">
          <!-- left column -->
          <div class="col-md-3">
            <div class="text-center">
              
              
              <img src="<?php if($row['img'] == NULL) echo "./assets/img/u1093.svg"; else echo "./assets/profile/".$row['img']; ?>" class="avatar img-circle" alt="avatar">
              
              <br>
              <br>
              <input type="file" class="form-control" name="imgProfile">
              
            </div>
          </div>
          
          <!-- edit form column -->
          <div class="col-md-9 personal-info">
                
              

              <div class="form-group">
                <p class="text">Nama Lengkap</p>
                <input type="text" name="username" id="username" class="form-control" placeholder="contoh : Rekrut Saya" value="<?php echo $row['username'] ?>">
            </div>
            <div class="form-group">
                <p class="text">E-mail</p>
                <input type="text" name="email" id="email" class="form-control" placeholder="contoh : test@gmail.com" value="<?php echo $row['email'] ?>">
            </div>

            <p class="text">Tanggal Lahir </p>
            
            <select id="day_start"
                    name="day_start" />
              <option>Tanggal</option>
              <option>1</option>      
              <option>2</option>      
              <option>3</option>      
              <option>4</option>      
              <option>5</option>      
              <option>6</option>      
              <option>7</option>      
              <option>8</option>      
              <option>9</option>      
              <option>10</option>      
              <option>11</option>      
              <option>12</option>      
              <option>13</option>      
              <option>14</option>      
              <option>15</option>      
              <option>16</option>      
              <option>17</option>      
              <option>18</option>      
              <option>19</option>      
              <option>20</option>      
              <option>21</option>      
              <option>22</option>      
              <option>23</option>      
              <option>24</option>      
              <option>25</option>      
              <option>26</option>      
              <option>27</option>      
              <option>28</option>      
              <option>29</option>      
              <option>30</option>      
              <option>31</option>      
            </select> 

            <select id="month_start"
                    name="month_start" />

              <option>Bulan</option>
              <option>Januari</option>      
              <option>Februari</option>      
              <option>Maret</option>      
              <option>April</option>      
              <option>Mei</option>      
              <option>Juni</option>      
              <option>Juli</option>      
              <option>Agustus</option>      
              <option>September</option>      
              <option>Oktober</option>      
              <option>November</option>      
              <option>Desember</option>      
            </select> 

            
            
            <select id="year_start"
                   name="year_start" />
              <option>Tahun</option>  
              <option>1986</option> 
              <option>1987</option>      
              <option>1988</option>      
              <option>1989</option>      
              <option>1990</option>      
              <option>1991</option>      
              <option>1992</option>      
              <option>1993</option>      
              <option>1994</option>      
              <option>1995</option>      
              <option>1996</option> 
              <option>1997</option> 
              <option>1998</option>      
              <option>1999</option>      
              <option>2000</option>      
              <option>2001</option>      
              <option>2002</option>      
              <option>2003</option>      
              <option>2004</option>      
              <option>2005</option>      
              <option>2006</option>      
              <option>2007</option>    
              <option>2008</option> 
              <option>2009</option>      
              <option>2010</option>      
              <option>2011</option>      
              <option>2012</option>      
              <option>2013</option>      
              <option>2014</option>      
              <option>2015</option>      
              <option>2016</option>      
              <option>2017</option>      
              <option>2018</option>   
              <option>2019</option>
              <option>2020</option>
            </select>

          <br><br>
          <div class="text">Jenis Kelamin</div>
            <select id="gender_start"
                    name="gender"/>
              <option>Pilih salah satu</option>
              <option>Laki - laki</option>      
              <option>Perempuan</option>          
            </select>
            <br><br>
            
            <div class="form-group">
                <p class="text">Nomor Telepon</p>
                <input type="text" name="handphone" id="phone" class="form-control" placeholder="contoh : 08218904XXXX" value="<?php echo $row['handphone'] ?>">
            </div>
            <div class="form-group">
                <p class="text">Password</p>
                <input type="text" name="password" id="password" class="form-control" placeholder="contoh : a1b2C3D4!@#">
            </div>
          
            <div class="form-group">
                <input type="submit" name="submit" class="btn btn-info btn-md" value="Ubah">
            </div>
            
                </div>
              </div>
            <br>
            <br>
            <?php } ?>       
            <label id="lblError" style="color: red;"> 
              <?php 
                if(isset($_SESSION['error'])){
                    echo $_SESSION['error'];
                }
                unset($_SESSION['error']);
              ?>
            </label>
            <br>
            </form>
        </div>
      
      
                  
    
                  
    <?php 
        include_once('./components/footer.php');
     ?>

</body>

</html>