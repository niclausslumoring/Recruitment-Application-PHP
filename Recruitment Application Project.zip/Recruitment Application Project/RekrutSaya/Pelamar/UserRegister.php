<!DOCTYPE html>
<html lang="en">

<?php 
    include_once('./helpers/session.php');
 ?>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekrut.Saya - Register</title>

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="./assets/css/PelamarSignUp.css">
    <link rel="stylesheet" href="./assets/css/option.css">

    <link rel='shortcut icon' type='image/x-icon' href='./assets/img/favicon.png' />

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
    <?php 
        include_once('./components/header.php');
     ?>


 <div id="login">
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="login-form" class="form" action="./controllers/doUserRegister.php" method="post">
                            <span class="Judul1"> Pendaftaran Pelamar</span>
                            <hr>
                            <div class="form-group">
                                <p class="text">Nama Lengkap</p>
                                <input type="text" name="username" id="username" class="form-control" placeholder="contoh : Rekrut Saya">
                            </div>
                            <div class="form-group">
                                <p class="text">E-mail</p>
                                <input type="text" name="email" id="email" class="form-control" placeholder="contoh : test@gmail.com">
                            </div>

                            <p class="text">Tanggal Lahir </p>
                            
                            <select id="day_start"
                                    name="day_start" />
                              <option>Tanggal</option>
                              <option>1</option>      
                              <option>2</option>      
                              <option>3</option>      
                              <option>4</option>      
                              <option>5</option>      
                              <option>6</option>      
                              <option>7</option>      
                              <option>8</option>      
                              <option>9</option>      
                              <option>10</option>      
                              <option>11</option>      
                              <option>12</option>      
                              <option>13</option>      
                              <option>14</option>      
                              <option>15</option>      
                              <option>16</option>      
                              <option>17</option>      
                              <option>18</option>      
                              <option>19</option>      
                              <option>20</option>      
                              <option>21</option>      
                              <option>22</option>      
                              <option>23</option>      
                              <option>24</option>      
                              <option>25</option>      
                              <option>26</option>      
                              <option>27</option>      
                              <option>28</option>      
                              <option>29</option>      
                              <option>30</option>      
                              <option>31</option>      
                            </select> 

                            <select id="month_start"
                                    name="month_start" />
                              <option>Bulan</option>
                              <option>Januari</option>      
                              <option>Februari</option>      
                              <option>Maret</option>      
                              <option>April</option>      
                              <option>Mei</option>      
                              <option>Juni</option>      
                              <option>Juli</option>      
                              <option>Agustus</option>      
                              <option>September</option>      
                              <option>Oktober</option>      
                              <option>November</option>      
                              <option>Desember</option>      
                            </select> 

                            
                            
                            <select id="year_start"
                                   name="year_start" />
                              <option>Tahun</option>  
                              <option>1986</option> 
                              <option>1987</option>      
                              <option>1988</option>      
                              <option>1989</option>      
                              <option>1990</option>      
                              <option>1991</option>      
                              <option>1992</option>      
                              <option>1993</option>      
                              <option>1994</option>      
                              <option>1995</option>      
                              <option>1996</option> 
                              <option>1997</option> 
                              <option>1998</option>      
                              <option>1999</option>      
                              <option>2000</option>      
                              <option>2001</option>      
                              <option>2002</option>      
                              <option>2003</option>      
                              <option>2004</option>      
                              <option>2005</option>      
                              <option>2006</option>      
                              <option>2007</option>    
                              <option>2008</option> 
                              <option>2009</option>      
                              <option>2010</option>      
                              <option>2011</option>      
                              <option>2012</option>      
                              <option>2013</option>      
                              <option>2014</option>      
                              <option>2015</option>      
                              <option>2016</option>      
                              <option>2017</option>      
                              <option>2018</option>   
                              <option>2019</option>
                              <option>2020</option>
                            </select>

                          <br><br>
                          <div class="text">Jenis Kelamin</div>
                            <select id="gender_start"
                                    name="gender" />
                              <option>Pilih salah satu</option>
                              <option>Laki - laki</option>      
                              <option>Perempuan</option>          
                            </select>
                            <br><br>
                            
                            <div class="form-group">
                                <p class="text">Nomor Telepon</p>
                                <input type="tel" name="handphone" id="phone" class="form-control" placeholder="contoh : 08218904XXXX">
                            </div>
                            <div class="form-group">
                                <p class="text">Password</p>
                                <input type="password" name="password" id="password" class="form-control" placeholder="contoh : a1b2C3D4!@#">
                            </div>
                          
                            <div class="form-group">
                                <input type="submit" name="submit" class="btn btn-info btn-md" value="Daftar">
                            </div>
                            <label id="lblError" style="color: red;"> 
                              <?php 
                                if(isset($_SESSION['error'])){
                                    echo $_SESSION['error'];
                                }
                                unset($_SESSION['error']);
                              ?>
                            </label>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
    <br>   
    <br>
    <br>   
    <br>


    <?php 
        include_once('./components/footer.php');
     ?>




</body>

</html>