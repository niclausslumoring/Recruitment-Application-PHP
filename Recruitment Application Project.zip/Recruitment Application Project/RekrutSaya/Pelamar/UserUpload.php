<div class="modal-content">
  <div class="modal-header ml-3">
    <span class="Judul2">Melamar pekerjaan</span>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
  </div>
  <div class="modal-body ml-3 mr-3">
    <h5>Cukup dengan mengupload CV anda di bawah ini, kami akan segera mengirimkan kepada pihak perusahaan</h5>
    <form action="./controllers/doSubmitApplicants.php?id=<?php if(isset($_GET['id'])) echo $_GET['id']; ?>" method="post" id="form_modal" enctype="multipart/form-data">
      <div class="row">
        <div class="col-3">
          <br>
          <input type="file" name="cv" id="cv" class="cv" style="display: none" accept="application/pdf" required>
          <label for="cv" style="color: #FDFFFC; background-color:#f49e4c; padding-left: 55px; padding-right: 55px; padding-top: 10px; padding-bottom: 10px; border-radius: 10px; font-size: 30px; cursor: pointer">Upload</label>
        </div>

        <div class="col">
          <label id="cv_text" style="padding-left: 55px; padding-right: 55px; padding-top: 10px; padding-bottom: 10px; border-radius: 10px; font-size: 30px;"></label>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <div id="kirim_box">
            <button type="submit" id="kirim" name="kirim">Kirim</button>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>