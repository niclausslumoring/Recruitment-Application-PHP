<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>footer</title>

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>

    <div class="footer container-fluid">
        <div class="row">
            <div class="col-md-5">
                <a href="index.php" id="brand">
                    <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
                </a>    
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="company">
                    
                    <div class="company_detail">
                        <span>Alamat : JL.KH.Syahdan,Jakarta</span><br>
                        <span>Telepon: 021-7539153</span><br>
                        <span>Email  : rekrutsaya@gmail.com</span>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <a href="index.php">Halaman Utama</a>
                <br>
                <a href="index.php#about_us">Tentang Kami</a>
                <br>
                <a href="FaqPage.php">FAQ</a>
                <br>
            </div>
            <div class="col-md-3">
                <a href="index.php#search_job">Cari Pekerjaan</a>
                <br>
                <a href="../Perusahaan/view/Company/LandingPage.php">Mendaftarkan Perusahaan</a>
                <br>
            </div>
            <div class="align-self-end col-md-3" style="color: black">
                <a href="">&#9400 Recruit.me 2020</a>
            </div>
        
        </div>
            
    </div>
</body>

</html>