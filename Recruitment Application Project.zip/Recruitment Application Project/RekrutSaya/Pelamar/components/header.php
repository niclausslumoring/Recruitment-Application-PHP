<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->

<?php if (isset($_SESSION['company_id'])) {


?>
    <nav class="navbar header">

        <!-- Logo -->
        <div class="mr-auto">
            <a href="../Perusahaan/view/Company/DashboardPage.php" id="brand" style="text-decoration: none;">
                <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
            </a>
        </div>

        <!-- Right Navbar Content-->
        <div class="ml-auto">
            <a href="CompEditProf.html" id="username" style="text-decoration: none; margin-right: 50px;">
                <img src="" alt="ProfilePicture" id="profile_picture" style="display: none; width: 30px; border-radius: 50%;">
                <span class="align-self-center ml-1" style="color: #f49e4c; display: inline-block;" id="username_navbar"></span>
            </a>
            <a href="./../Perusahaan/DBHelper/API/LogoutComp.php" id="keluar" style="text-decoration: none; margin-right: 100px;"><span>Keluar</span></a>
        </div>
    </nav>


<?php } else if (isset($_SESSION['user_id'])) {

?>
    <nav class="navbar header">

        <!-- Logo -->
        <div class="mr-auto">
            <a href="DashboardPage.php" id="brand" style="text-decoration: none;">
                <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
            </a>
        </div>

        <!-- Right Navbar Content-->
        <div class="ml-auto">
            <a href="UserProfile.php?id=<?php echo $_SESSION['user_id'] ?>" id="username" style="text-decoration: none; margin-right: 50px;">
                <i class="fas fa-user-circle" style="font-size: 25px; display: inline-block; color: #f49e4c;"></i>
                <span class="align-self-center" style="color: #f49e4c; display: inline-block;"><?php echo $_SESSION['username'] ?></span>
            </a>
            <a href="./controllers/doUserLogout.php" id="keluar" style="text-decoration: none; margin-right: 100px;"><span>Keluar</span></a>
        </div>
    </nav>
<?php
} else {
?>
    <nav class="navbar header">
        <div class="mr-auto">
            <a href="index.php" id="brand">
                <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
            </a>
        </div>

        <div class="ml-auto">
            <a href="UserLogin.php" id="masuk">
                <span class="masuk">Masuk</span>
            </a>
            <a href="UserRegister.php" id="daftar">
                <span class="daftar">Daftar</span>
            </a>
            <a href="../Perusahaan/view/Company/LandingPage.php" id="pelamar"><span class="pelamar">Perusahaan</span></a>
        </div>
    </nav>
<?php } ?>