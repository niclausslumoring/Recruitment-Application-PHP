<?php
include_once './../helpers/session.php';
include_once './../db/database.php';
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["applicant"])) {
    $id = $_SESSION['user_id'];
    $username = $_SESSION['username'];

    $query = "SELECT a.*,j.JobName FROM applicants a JOIN job j ON a.JobID = j.ID WHERE ApplicantName='$username' AND ApplicantID=$id";
    $result = mysqli_query($conn,$query);
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }

    if (isset($data)) {
        echo json_encode($data);
    } else {
        echo 'no data';
    }
}
