<?php
include_once './../helpers/session.php';
include_once './../db/database.php';
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["job_id"])) {
    $id = $_GET['job_id'];
    $status = 'Open';

    $query = "SELECT * FROM job j JOIN jobdetail jd ON j.ID = jd.ID JOIN company c ON j.CompanyID = c.ID JOIN location l ON j.JobLocation = l.ID WHERE j.ID=? AND Status=? LIMIT 1";
    $login = $connection->prepare($query);
    $login->bind_param('ss', $id, $status);
    $login->execute();
    $result = $login->get_result();

    if ($user_data[] = $result->fetch_assoc()) {
        echo json_encode($user_data);
    } else {
        echo 'no data';
    }
}
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["query"])) {
    $id = $_GET['query'];
    $status = 'Open';

    $query = "SELECT * FROM job j JOIN company c ON j.CompanyID = c.ID JOIN jobdetail jd ON j.ID = jd.ID JOIN location l ON j.JobLocation = l.ID JOIN salary s ON j.Salary = s.ID JOIN jobtype jt ON j.JobType = jt.ID WHERE l.Location LIKE '$id' OR s.salary LIKE '$id' OR jt.JobType LIKE '$id'" ;
    $result = mysqli_query($conn,$query);
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }
    // echo json_encode($data);
    if (isset($data)) {
        echo json_encode($data);
    } else {
        echo 'no data';
    }
}
