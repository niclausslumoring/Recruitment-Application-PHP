<?php
  include_once './../helpers/session.php';
  include_once './../db/database.php';

  if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['submit']))
  {
      $jobtype = $_GET['job_type'];
      $location = $_GET['location'];
      $salary = $_GET['salary'];

      $query = "SELECT * FROM job j 
        JOIN jobtype t ON j.JobType = t.ID 
        JOIN location l ON j.JobLocation = l.ID
        JOIN salary s ON j.Salary = s.ID
        JOIN company c ON j.CompanyID = c.ID
        JOIN jobdetail d ON j.ID = d.ID
        ";

      $conditions = array();
  
      if(! empty($jobtype)) {
        $conditions[] = "t.JobType='%$jobtype%'";
      }
      if(! empty($location)) {
        $conditions[] = "l.Location='%$location%'";
      }
      if(! empty($salary)) {
        $conditions[] = "s.salary='%$salary%'";
      }
  
      $sql = $query;
      if (count($conditions) > 0) {
        $sql .= " WHERE " . implode(' AND ', $conditions);
      }
      
      $result = mysqli_query($sql);

      header('location: ./../Search.php');
      
      
  }
?>