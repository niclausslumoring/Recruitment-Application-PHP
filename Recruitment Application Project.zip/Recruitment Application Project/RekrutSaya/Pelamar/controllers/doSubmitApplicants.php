<?php
include_once './../helpers/session.php';
include_once './../db/database.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['kirim'])) {
    $id = $_SESSION['user_id'];
    $jobID = $_GET['id'];
    $username = $_SESSION['username'];
    $date = date('Y-m-d');
    $file_name = basename($_FILES["cv"]["name"]);
    if ($file_name != "") {
        $new_path = $id.",".$username.",".$jobID.".".pathinfo($file_name, PATHINFO_EXTENSION);
        $target_dir = "../assets/CV/";
        $target_file = $target_dir . $new_path;
        move_uploaded_file($_FILES["cv"]["tmp_name"], $target_file);
    }
    else echo'<script>alert("terjadi error")</script>';
    $insert_applicants_query =
        "INSERT INTO applicants (ApplicantID, ApplicantName, JobID, Date, CVLocation) VALUES (?, ?, ? ,? ,?)";
    $insert_user = $connection->prepare($insert_applicants_query);
    $insert_user->bind_param("sssss", $id, $username, $jobID, $date, $target_file);
    $insert_user->execute();

    header('location: ../DashboardPage.php');
}
