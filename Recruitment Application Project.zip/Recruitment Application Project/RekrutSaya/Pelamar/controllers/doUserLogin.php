<?php
    include_once './../helpers/session.php';
    include_once './../db/database.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
      	$username = $_POST["username"];
      	$password = $_POST["password"];

      	$query = "SELECT * FROM users WHERE username=? AND password=SHA1(?) LIMIT 1";
        $login = $connection->prepare($query);
        $login->bind_param('ss', $username, $password);
        $login->execute();
        $result = $login->get_result();

      	if($user_data = $result->fetch_assoc()){
            $_SESSION['user_id']    = $user_data['id'];
            $_SESSION['username']   = $user_data['username'];
            header('location: ./../DashboardPage.php');
        }

        else{
            $_SESSION['error'] = "Username atau kata sandi salah";
            header('location: ./../UserLogin.php');
        }
    }
    
?>
