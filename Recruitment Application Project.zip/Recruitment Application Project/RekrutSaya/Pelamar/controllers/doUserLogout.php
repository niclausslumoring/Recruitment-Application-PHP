<?php
	
	include_once './../helpers/session.php';
	session_unset();
	session_destroy();
	header('Location: ./../index.php');
?>