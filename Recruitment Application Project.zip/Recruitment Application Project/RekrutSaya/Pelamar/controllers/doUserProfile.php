<?php 
	include_once './../helpers/session.php';
	include_once './../db/database.php';

	if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
      	$username = $_POST['username'];
		$email = $_POST['email'];
		// $dob = $_POST['dob'];
		$gender = $_POST['gender'];
		$handphone = $_POST['handphone'];
		$password = $_POST['password'];


		$y = $_POST['year_start'];
        $m = $_POST['month_start'];
        $d = $_POST['day_start'];
        $dob = $d." ".$m." ".$y;

		$id = $_SESSION['user_id'];

      	$query = "UPDATE users
			SET username =?, email =?, dob =?, gender =?, handphone =?, password =SHA1(?)
			WHERE id=?";

        $login = $connection->prepare($query);
        $login->bind_param('ssssssi', $username, $email, $dob, $gender, $handphone, $password, $id);
        $login->execute();

		
		//upload file 
    	$temp = $_FILES['imgProfile']['tmp_name'];
		$name = $_FILES['imgProfile']['name'];
		$size = $_FILES['imgProfile']['size'];
		$type = $_FILES['imgProfile']['type'];
		$folder = $_SERVER['DOCUMENT_ROOT']."/assets/profile/";
		
		if ($size < 1024000 and $type =='image/jpeg') {
		    // upload Process
		    $file_name = "$username.$type";
		    move_uploaded_file($file_name, $folder);
		    $query = "UPDATE users SET img=$file_name";
		    mysqli_query($connection, $query);
		}else{
		    $_SESSION['error'] = "size harus dibawah 1024kb dengan ekstensi img/jpg/jpeg";
		}	

		echo ("<script LANGUAGE='JavaScript'>
   	 	window.alert('Profil Berhasil Diupdate');
    	window.location.href='./../DashboardPage.php';
    	</script>"); 
    }
 ?>