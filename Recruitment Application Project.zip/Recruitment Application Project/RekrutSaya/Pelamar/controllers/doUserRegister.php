<?php 
	include_once './../helpers/session.php';
	include_once './../db/database.php';
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])){

		$username = $_POST['username'];
		$email = $_POST['email'];
		$gender = $_POST['gender'];
		$handphone = $_POST['handphone'];
		$password = $_POST['password'];


        $y = $_POST['year_start'];
        $m = $_POST['month_start'];
        $d = $_POST['day_start'];
        
		if(!$username || !$email || !$handphone || !$password || $y == "Tahun" || $m == "Bulan" || $d == "Tanggal" || $gender == "Pilih salah satu"){
            $_SESSION['error'] = "field tidak boleh kosong";
            header('Location: ./../UserRegister.php');
            die();
        }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {  
            $_SESSION['error'] = "Masukkan format email yang benar";
            die();
        }

        $check_user_query = 
            "SELECT 1 FROM users WHERE username=?";
        $check_user = $connection->prepare($check_user_query);
        $check_user->bind_param("s", $username);
        $check_user->execute();
        $result = $check_user->get_result();

        if($user_data = $result->fetch_assoc()){
        	$_SESSION['error'] = "Username telah dipakai. Masukkan username lain";
            header('Location: ./../UserRegister.php');
            die();
        }

        $insert_user_query = 
            "INSERT INTO users (username, email, day, month, year, gender, handphone, password) VALUES (?, ?, ?, ?, ?, ?, ?, SHA1(?))";
        $insert_user = $connection->prepare($insert_user_query);
        $insert_user->bind_param("ssssssss", $username, $email, $d, $m, $y, $gender, $handphone, $password);
        $insert_user->execute();
        
        header('Location: ./../UserLogin.php');   
    }
		
	
 
 ?>