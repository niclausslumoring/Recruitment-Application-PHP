<?php

    $server_address = 'localhost';
    $username       = 'root';
    $password       = '';
    $database       = 'rekrutsaya';
?>