<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->
<?php
include_once('./helpers/session.php');
?>


<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekrut Saya</title>

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="./assets/css/index.css">

    <link rel='shortcut icon' type='image/x-icon' href='./assets/img/favicon.png' />

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>

    <script type="text/javascript" src="./Javascript/LandingPage.js"></script>
</head>

<body>
    <?php
    include('./components/header.php');
    ?>


    <div class="home_1 container-fluid">
        <img src="./assets/img/u9.jpg" alt="photo" id="home1_pict">
        <div id="home_1_1">
            <span class="Judul1" id="search_job">Cari pekerjaan impianmu di sini!</span>
            <br><br>
            <h5>Cukup dengan memasukan beberapa kata kunci, kami akan memberikan pekerjaan yang sesuai dengan anda.</h5>
            <br>
            <form class="form-inline">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Cari posisi, lokasi, dan jenis pekerjaan" aria-label="Search">
            </form>
        </div>

    </div>


    <div class="home_2">
        <span class="Judul1">Lokasi yang banyak dicari</span>
        <br><br>
        <div class="location">
            <a href="#">
                <span class="location_list">Jakarta Selatan</span>
            </a>
            <a href="#">
                <span class="location_list">Jakarta Barat</span>
            </a>
            <a href="#">
                <span class="location_list">Jakarta Utara</span>
            </a>
            <a href="#">
                <span class="location_list">Jakarta Timur</span>
            </a>
            <a href="#">
                <span class="location_list">Bandung</span>
            </a>
        </div>

    </div>

    <div class="home_3 container mb-5" id="about_us">
        <span class="Judul1">Apa itu Rekrut.<span class="Judul2">Saya</span></span>
        <h3 id="text_home3">Rekruit.Saya merupakan perusahaan perantara penyedia lowongan kerja diseluruh indonesia. Dengan bekerjasama
            dengan berbagai perusahaan dalam negeri maupun perusahaan asing, sehingga memiliki banyak lowongan kerja.
            Recruit.Me memudahkan anda dalam mencari pekerjaan impian anda.</h3>
    </div>

    <div class="home_4 container mb-5">
        <span class="Judul1">Mengapa Rekrut.<span class="Judul2">Saya ?</span></span>

        <div class="row a">
            <div class="col-md-4">
                <img src="./assets/img/lowongan.png" alt="gambar lowongan" class="gambar">
                <br>
                <span class="Judul3">Banyak Lowongan</span>
                <h3 id="text_home3">Kami telah bekerjasama dengan beberapa perusahaan besar. Sehingga kesempatan mendapatkan lowongan kerja pun menjadi semakin luas.</h3>
            </div>
            <div class="col-md-4">
                <img src="./assets/img/terpercaya.png" alt="gambar terpercaya" class="gambar">
                <br>
                <span class="Judul3">Perusahaan Terpercaya</span>
                <h3 id="text_home3">Semua perusahaan yang mendaftarkan lowongan pekerjaan di tempat kami telah kami cek kebenarannya.</h3>
            </div>
            <div class="col-md-4">
                <img src="./assets/img/rahasia.png" alt="gambar rahasia" class="gambar">
                <br>
                <span class="Judul3">Kerahasiaan Terjamin</span>
                <h3 id="text_home3">Anda tidak perlu khawatir data pribadi anda disalahgunakan. Kami selalu menjaga keamanan sistem.</h3>
            </div>
        </div>
    </div>

    <div class="home_5 mt-5">
        <a href="UserRegister.php">
            <button name="submit" id="btn_gabung"<?php if(isset($_SESSION['company_id'])) echo 'disabled' ?>>Gabung Sekarang</button>
        </a>
    </div>
    <br>
    <br>
    <br>
    <br>


    <?php
    include('./components/footer.php');
    ?>




</body>

</html>