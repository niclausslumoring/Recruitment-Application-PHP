<?php
if (isset($_POST['accept'])) {
    $conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $ID = $_POST['id'];

    $query = "UPDATE applicants SET Status = 'Accept' WHERE ID = '$ID'";
    if ($result = mysqli_query($conn, $query)) {
        echo 'success';
    }
}
if (isset($_POST['deny'])) {
    $conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $ID = $_POST['id'];

    $query = "UPDATE applicants SET Status = 'Deny' WHERE ID = '$ID'";
    if ($result = mysqli_query($conn, $query)) {
        echo 'success';
    }
}