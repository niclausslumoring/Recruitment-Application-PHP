<?php
session_start();
if (isset($_POST['add_job'])) {
    $conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $ID = $_SESSION['company_id'];
    $date = date('Y-m-d');
    $job_name = $_POST['job_name'];
    $job_type = $_POST['job_type'];
    $location = $_POST['location'];
    $salary = $_POST['salary'];
    $facility_check = implode(", ", $_POST['facility_check']);
    $job_desc = $_POST['job_desc'];
    $job_requirment = $_POST['job_requirment'];
    $file_name = basename($_FILES["photo"]["name"]);
    if ($file_name != "") {
        $target_dir = "../../assets/JobPlace/";
        $target_file = $target_dir . $file_name;
    }
    $ready = 1;

    if (isset($target_file) && move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
        $ready = 1;
    }

    if ($ready) {
        $query = "INSERT INTO job(CompanyID, JobName, InputDate, ChangeDate, JobLocation, JobType, Salary, Status) Values('$ID', '$job_name','$date', '$date', '$location','$job_type','$salary', 'Open')";
        if ($result = mysqli_query($conn, $query)) {
            if (isset($target_file)) {
                $query = "INSERT INTO jobdetail(Facility, Photo, Description, JobCondition) Values('$facility_check','$target_file','$job_desc','$job_requirment')";
            } else $query = "INSERT INTO jobdetail(Facility, Description, JobCondition) Values('$facility_check','$job_desc','$job_requirment')";
            if ($result = mysqli_query($conn, $query)) {
                mysqli_close($conn);
                echo '<script>alert("Pekerjaan berhasil ditambahkan");window.location="../../view/Company/DashboardPage.php";</script>';
            } else echo ("Errorcode: " . mysqli_error($conn));
        } else {
            echo ("Errorcode: " . mysqli_errno($conn));
        }
    }
}
