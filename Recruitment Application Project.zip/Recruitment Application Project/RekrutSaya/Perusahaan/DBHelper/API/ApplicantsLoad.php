<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if (isset($_GET['status'])) {
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $id = $_GET['id'];
    $applicant = $_GET['applicant'];
    $query = "SELECT Status FROM applicants WHERE JobID = '$id' AND ID = '$applicant'";
    $result = mysqli_query($conn, $query);
    while($row = mysqli_fetch_assoc($result)){
        $data = $row['Status'];
    }
    if(!isset($data)) echo 'empty';
    else echo $data;
    mysqli_close($conn);
}
if (isset($_GET['job'])) {
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $flag = false;
    $job = $_SESSION['job_id'];
    $query = "SELECT * FROM applicants WHERE JobID = '$job'";
    $result = mysqli_query($conn, $query);
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
        $flag = true;
    }
    if(!$flag) echo 'no data';
    else echo json_encode($data);
    mysqli_close($conn);
}