<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if (isset($_COOKIE['company_email']) && isset($_COOKIE['company_password'])) {
    echo '<script>alert"tes"</script>';
    $company_email = $_COOKIE['company_email'];
    $company_password = $_COOKIE['company_password'];
    $query = "SELECT * FROM company WHERE CompanyEmail = '$company_email'";
    $result = mysqli_query($conn, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        $hashed = $row["Password"];
        if (password_verify($company_password, $hashed)) {
            mysqli_close($conn);
            $_SESSION['company_id'] = $row['ID'];
            header('location: ../../view/Company/DashboardPage.php');
        }
    }
    mysqli_close($conn);
} else {
    session_destroy();
    session_unset();
    setcookie("company_email", "", time() - 1);
    setcookie("company_password", "", time() - 1);
    mysqli_close($conn);
    header('location: ../../view/Company/CompSignIn.php');
}
