<?php
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if (isset($_GET['check'])) {
    $company_email = $_GET['email'];
    $company_password = $_GET['password'];
    $flag = "";
    $query = "SELECT * FROM company WHERE CompanyEmail = '$company_email'";
    $result = mysqli_query($conn, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        $hashed = $row["Password"];
        if (password_verify($company_password, $hashed)) {
            $flag = "benar";
            break;
        } else {
            $flag = "salah";
        }
    }
    echo $flag;
    mysqli_close($conn);
}
if (isset($_GET['check_email'])) {
    $company_email = $_GET['email'];
    $flag = "";
    $query = "SELECT * FROM company WHERE CompanyEmail = '$company_email'";
    $result = mysqli_query($conn, $query);
    if(mysqli_num_rows($result) > 0) $flag = 'benar';
    else  $flag = 'salah';
    echo $flag;
    mysqli_close($conn);
}

