<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if (isset($_POST['submit'])) {
    $company_email = $_POST['email'];
    $company_password = $_POST['password'];
    if (isset($_POST['remember_me'])) {
        $remember_me = $_POST['remember_me'];
    }
    $query = "SELECT * FROM company WHERE CompanyEmail = '$company_email'";
    $result = mysqli_query($conn, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        $hashed = $row["Password"];
        if (password_verify($company_password, $hashed)) {
            mysqli_close($conn);
            unset($_SESSION['email']);
            unset($_SESSION['password']);
            $_SESSION['company_id'] = $row['ID'];
            if (isset($_POST['remember_me'])) {
                setcookie('company_email', $company_email, time() + (30 * 24 * 60 * 60));
                setcookie('company_password', $company_password, time() + ((30 * 24 * 60 * 60)));
            }

            header('location: ../../view/Company/DashboardPage.php');
        } else {
            $_SESSION['insert_email'] = $company_email;
            $_SESSION['password'] = false;
            header('location: ../../view/Company/CompSignIn.php');
        }
    }
    if (mysqli_num_rows($result) < 1) {
        $_SESSION['email'] = false;
        header('location: ../../view/Company/CompSignIn.php');
    }
}
