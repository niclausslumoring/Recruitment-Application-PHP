<?php
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if (isset($_GET['status'])) {
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $id = $_GET['id'];
    $query = "SELECT Status FROM job WHERE ID = '$id'";
    $result = mysqli_query($conn, $query);
    while($row = mysqli_fetch_assoc($result)){
        $data = $row['Status'];
    }
    echo $data;
    mysqli_close($conn);
}
if (isset($_GET['job'])) {
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $flag = false;
    $id = $_GET['comp_id'];
    $query = "SELECT * FROM job WHERE CompanyID = '$id'";
    $result = mysqli_query($conn, $query);
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
        $flag = true;
    }
    if(!$flag) echo 'no data';
    else echo json_encode($data);
    mysqli_close($conn);
}
