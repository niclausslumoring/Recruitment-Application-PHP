<?php
session_start();
if (isset($_POST['edit_prof'])) {
    $conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $ID = $_SESSION['company_id'];
    $company_name = $_POST['company_name'];
    $email = $_POST['company_email'];
    $address = $_POST['company_address'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $desc = $_POST['company_desc'];
    if ($password != '') {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $flag = "";
    }
    $target_dir = "../../assets/ProfilePicture/";
    $file_name = basename($_FILES["photo"]["name"]);
    if ($file_name != "") {
        $target_file = $target_dir . $file_name;
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file))
            $ready = 1;
    }
    if (isset($flag) && isset($ready)) {
        $query = "UPDATE company SET CompanyName = '$company_name', CompanyEmail = '$email', CompanyAddress = '$address', CompanyPhone = '$phone', Password = '$hashed_password', ProfilePictureAddress = '$target_file', CompanyDesc = '$desc' WHERE ID = '$ID'";
    } else if (isset($flag) && !isset($ready)) {
        $query = "UPDATE company SET CompanyName = '$company_name', CompanyEmail = '$email', CompanyAddress = '$address', CompanyPhone = '$phone', Password = '$hashed_password', CompanyDesc = '$desc' WHERE ID = '$ID'";
    } else if (!isset($flag) && isset($ready)) {
        $query = "UPDATE company SET CompanyName = '$company_name', CompanyEmail = '$email', CompanyAddress = '$address', CompanyPhone = '$phone', ProfilePictureAddress = '$target_file', CompanyDesc = '$desc' WHERE ID = '$ID'";
    } else $query = "UPDATE company SET CompanyName = '$company_name', CompanyEmail = '$email', CompanyAddress = '$address', CompanyPhone = '$phone', CompanyDesc = '$desc' WHERE ID = '$ID'";;
    if ($result = mysqli_query($conn, $query)) {
        echo '<script>alert("Profile berhasil diubah");window.location="../../view/Company/CompEditProf.html";</script>';
    } else {
        echo '<script>console.log("error");</script>';
    }
    mysqli_close($conn);
}
