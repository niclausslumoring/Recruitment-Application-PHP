<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if(isset($_GET['loadJob'])){
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $ID = $_GET['ID'];
    $JobID = $_GET['JobID'];
    $query = "SELECT * FROM job j JOIN jobdetail jd on j.ID = jd.ID WHERE j.CompanyID = '$ID' AND j.ID = '$JobID'";
    $result = mysqli_query($conn,$query);
    while($row = mysqli_fetch_assoc($result)){
        $data = $row;
    }
    echo json_encode($data);
    mysqli_close($conn);
}