<?php
if (isset($_POST['add_job'])) {
    $conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $ID = $_POST['job_id'];
    $date = date('Y-m-d');
    $job_name = $_POST['job_name'];
    $job_type = $_POST['job_type'];
    $location = $_POST['location'];
    $salary = $_POST['salary'];
    $facility_check = implode(", ", $_POST['facility_check']);
    $job_desc = $_POST['job_desc'];
    $job_requirment = $_POST['job_requirment'];
    $file_name = basename($_FILES["photo"]["name"]);
    if ($file_name != "") {
        $target_dir = "../../assets/JobPlace/";
        $target_file = $target_dir . $file_name;
    }

    $ready = 1;

    if (isset($target_file) && move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
        $ready = 1;
    }

    if ($ready) {
        echo '<script>console.log("' . $facility_check . '");</script>';
        $query = "UPDATE job SET JobName = '$job_name',ChangeDate = '$date', JobLocation = '$location', JobType = '$job_type',Salary = '$salary' WHERE ID = '$ID'";
        if ($result = mysqli_query($conn, $query)) {
            if (isset($target_file)) {
                $query = "UPDATE jobdetail SET Facility = '$facility_check', Photo = '$target_file' , Description = '$job_desc',JobCondition = '$job_requirment' WHERE ID = '$ID'";
            } else $query = "UPDATE jobdetail SET Facility = '$facility_check', Description = '$job_desc',JobCondition = '$job_requirment' WHERE ID = '$ID'";

            if ($result = mysqli_query($conn, $query)) {
                mysqli_close($conn);
                echo '<script>alert("Pekerjaan berhasil diedit");window.location="../../view/Company/DashboardPage.php";</script>';
            }
        }
    }
}
