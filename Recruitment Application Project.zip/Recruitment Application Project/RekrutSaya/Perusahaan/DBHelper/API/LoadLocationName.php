<?php
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if(isset($_GET['location'])){
    $location = $_GET['location'];
    $query = "SELECT Location FROM location WHERE ID = '$location'";
    if($result = mysqli_query($conn,$query)){
        $row = mysqli_fetch_assoc($result);
        echo $row['Location'];
    }
    else mysqli_error($conn);
}
mysqli_close($conn);