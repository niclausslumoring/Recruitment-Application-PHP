<?php
$conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
if(isset($_GET['type'])){
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $query = "SELECT * FROM jobtype";
    $result = mysqli_query($conn,$query);
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }
    echo json_encode($data);
    mysqli_close($conn);
}
if(isset($_GET['salary'])){
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $query = "SELECT * FROM salary";
    $result = mysqli_query($conn,$query);
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }
    echo json_encode($data);
    mysqli_close($conn);
}
if(isset($_GET['location'])){
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $query = "SELECT * FROM location";
    $result = mysqli_query($conn,$query);
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }
    echo json_encode($data);
    mysqli_close($conn);
}