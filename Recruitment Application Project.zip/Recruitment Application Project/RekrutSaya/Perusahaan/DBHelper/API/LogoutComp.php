<?php
session_start();
setcookie("company_email", "", time() - 1);
setcookie("company_password", "", time() - 1);
session_unset('company_id');
session_unset();
session_destroy();
header('location: ../../view/Company/LandingPage.php');