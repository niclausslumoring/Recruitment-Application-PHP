<?php
if (isset($_POST['open'])) {
    $conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $ID = $_POST['id'];

    $query = "UPDATE job SET Status = 'Open' WHERE ID = '$ID'";
    if ($result = mysqli_query($conn, $query)) {
        echo 'success';
    }
}
if (isset($_POST['close'])) {
    $conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $ID = $_POST['id'];

    $query = "UPDATE job SET Status = 'Close' WHERE ID = '$ID'";
    if ($result = mysqli_query($conn, $query)) {
        echo 'success';
    }
}