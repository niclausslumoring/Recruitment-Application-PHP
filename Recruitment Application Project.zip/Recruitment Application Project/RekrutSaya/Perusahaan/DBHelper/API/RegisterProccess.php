<?php
if(isset($_POST['register'])){
    $conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $company_name = $_POST['company_name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    $query = "SELECT * FROM company WHERE CompanyName = '$company_name' AND CompanyEmail = '$email' AND CompanyPhone = '$phone'";
    $result = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_assoc($result)) {
        echo '<script>alert("Perusahaan sudah terdaftar");window.location="LandingPage.php";</script>';
    }
    else{
        $query = "INSERT INTO company(CompanyName,CompanyEmail,CompanyAddress,CompanyPhone,Password) Values('$company_name', '$email', '$address', '$phone', '$hashed_password')";
        if(mysqli_query($conn, $query)){
            mysqli_close($conn);
            echo '<script>alert("Perusahaan berhasil terdaftar");window.location="../../view/Company/CompSignIn.php";</script>';
        }
    }
}