<?php
session_start();
$_SESSION['job_id'] = $_GET['job_id'];
if(isset($_GET['applicant'])){
    header('location: ../../view/Company/JobDetail.html');
}
if(isset($_GET['job_id']) && !isset($_GET['applicant'])){
    header('location: ../../view/Company/EditJobPage.php');
}
