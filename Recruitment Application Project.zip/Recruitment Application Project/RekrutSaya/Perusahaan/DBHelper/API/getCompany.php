<?php
session_start();
if(isset($_GET['id'])){
    $id = $_SESSION['company_id'];
    echo $id;
}
if(isset($_GET['info'])){
    $conn = mysqli_connect('localhost', 'root', '', 'rekrutsaya');
    if (mysqli_connect_errno()) {
        die("Failed to connect to db: " . mysqli_connect_error());
    }
    $id = $_GET['company_id'];
    $query = "SELECT * FROM company WHERE ID = '$id'";
    $result = mysqli_query($conn, $query);
    while($row = mysqli_fetch_assoc($result)){
        $data = $row;
    }
    echo json_encode($data);
    mysqli_close($conn);
}
