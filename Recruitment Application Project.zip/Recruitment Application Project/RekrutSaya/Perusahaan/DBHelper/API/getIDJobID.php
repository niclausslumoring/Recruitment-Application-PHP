<?php
session_start();
if(isset($_GET['ID'])){
    $id = $_SESSION['company_id'];
    echo $id;
}
if(isset($_GET['JobID'])){
    $JobID = $_SESSION['job_id'];
    echo $JobID;
}