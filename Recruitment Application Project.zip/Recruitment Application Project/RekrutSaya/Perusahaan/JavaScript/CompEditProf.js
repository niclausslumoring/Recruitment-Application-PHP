var id = 0;
var cek;

function getCompanyLogged() {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'id': 1 },
        success: function(data) {
            id = data;
        }
    }).done(function(resp) {
        getCompanyInfo(id);
    })
}

$(document).ready(function() {
    getCompanyLogged();
    $('.photo').on('change', function(e) {
        var fileName = '';
        fileName = e.target.value.split('\\').pop();

        if (fileName)
            $('#input_photo').text(fileName);
        readURL(this);
    });

    function removeErrorMessage() {
        $(".error_message").empty();
    }

    function appendErrorMessage(x) {
        $(".error_message").append('<span class="error" style="color: red;">' + x + '</span><br>');
    }

    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    $('#form_edit_profile').on('submit', function(event) {
        removeErrorMessage();

        let valid = true;
        const email = $('#company_email').val().toString();
        const password = $('#password').val().toString();

        if (!validateEmail(email)) {
            appendErrorMessage('Email tidak sesuai format Email');
            valid = false;
        }
        if (password != "") {
            if (password.length < 8) {
                appendErrorMessage('Panjang password kurang dari 8 karakter');
                valid = false;
            }
        }

        if (valid) {
            $(this).submit();
        } else {
            event.preventDefault();
        }
    })
})

function readURL(input) {
    if (input.files) {
        var reader = new FileReader();

        reader.onload = function(e) {
            $('img#avatar').attr('src', e.target.result);
            console.log($('img#avatar'));
        }

        reader.readAsDataURL(input.files[0]);
    }
}

function getCompanyInfo(x) {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'info': 1, 'company_id': x },
        success: function(data) {
            console.log(data);
            var company = JSON.parse(data);
            if (company.ProfilePictureAddress != "") {
                var template = $('#profile_picture').clone().attr("src", company.ProfilePictureAddress).show();
            } else {
                var template = $('#profile_picture').clone().attr('src', '../../assets/defaultComp.png').show();
            }
            $(template).insertBefore('#username_navbar');
            var temp_con = $(template).clone().attr('id', 'avatar').attr('style', 'width: 150px; border-radius: 50%;');
            $(temp_con).insertBefore('#insert_here');
            $('#username_navbar').text(company.CompanyName);

            $("#company_name").attr('value', company.CompanyName);
            $("#company_email").attr('value', company.CompanyEmail);
            $("#company_address").attr('value', company.CompanyAddress);
            $("#phone").attr('value', company.CompanyPhone);
            $("#company_desc").attr('value', company.CompanyDesc);

        }
    })
}