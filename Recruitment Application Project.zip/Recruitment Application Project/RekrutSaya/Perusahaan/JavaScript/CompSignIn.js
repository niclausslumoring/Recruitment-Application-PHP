function removeErrorMessage() {
    $(".error_message").empty();
}

function appendErrorMessage(x) {
    $(".error_message").append('<span class="error" style="color: red;">' + x + '</span><br>');
}

function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

$(document).ready(function() {
    $('#login-form').on('submit', function(event) {
        removeErrorMessage();
        let valid = true;
        const email = $('#email').val().toString();
        const password = $('#password').val().toString();

        if (!validateEmail(email)) {
            appendErrorMessage('Email tidak sesuai format Email');
            valid = false;
        } else if (password.length < 8) {
            appendErrorMessage('Password salah');
            valid = false;
        }

        if (valid) {
            $(this).submit();
        } else {
            event.preventDefault();
        }


    })

})