var id = 0;

function getCompanyLogged() {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'id': 1 },
        success: function(data) {
            id = data;
        }
    }).done(function(resp) {
        loadJob(id);
        getCompanyInfo(id);
    })
}

function getCompanyInfo(x) {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'info': 1, 'company_id': x },
        success: function(data) {
            var company = JSON.parse(data);
            if (company.ProfilePictureAddress != "") {
                var template = $('#profile_picture').clone().attr("src", company.ProfilePictureAddress).attr('style', 'width: 30px; border-radius: 50%;').show();
            } else {
                var template = $('#profile_picture').clone().attr('src', '../../assets/defaultComp.png').attr('style', 'width: 30px; border-radius: 50%;').show();
            }
            $(template).insertBefore('#username_navbar');
            var temp_con = $(template).clone().attr("style", 'width: 150px; margin-left: 100px; margin-bottom: 50px; border-radius: 50%;');
            $('#username_navbar').text(company.CompanyName);
            $('#username_content_text').text(company.CompanyName);
            $(temp_con).insertBefore('#username_content');

        }
    })
}
$(document).ready(function() {

    getCompanyLogged();


});



function loadJob(x) {
    $.ajax({
        url: '../../DBHelper/API/DashboardProccess.php',
        method: 'GET',
        data: { 'job': 1, 'comp_id': x },
        success: function(data) {
            if (data == 'no data') {
                var template = $('.empty').clone().show();
                $('#table_body').append(template);
                $('.empty').append('<td class="empty" colspan="4">Belum ada pekerjaan</td>');
            } else {
                var job = JSON.parse(data);
                var counter = 0;
                while (counter < job.length) {
                    var template = $('.job_info', '#table_template').clone().removeClass('.job_info').attr('id', job[counter].ID).data("job", job[counter]).show();
                    var date = convertDate(job[counter]);
                    $('#iNo', template).text(counter + 1);
                    $('#iJobName', template).text(job[counter].JobName);
                    $('#iDate', template).text(date);
                    $('#tooltip #edit_job', template).click(function() {
                        goTo($(this).parent().parent().data('job').ID);
                    })
                    $('#tooltip #applicants', template).click(function() {
                        goToApplicants($(this).parent().parent().data('job').ID);
                    })
                    console.log(job[counter].ID)
                    $('#table_body').append(template);
                    loadStatus(job[counter].ID);
                    changeStatus(job[counter].ID);

                    counter++;
                }

            }
        }
    })
}

function openJob(x) {
    $.ajax({
        url: '../../DBHelper/API/OpenCloseJob.php',
        method: 'post',
        data: { 'id': x, 'open': 1 },
        success: function(data) {
            if (data == 'success') alert('Pekerjaan dibuka');
        }
    })
}

function closeJob(x) {
    if (confirm('konfirmasi penutupan lowongan')) {
        $.ajax({
            url: '../../DBHelper/API/OpenCloseJob.php',
            method: 'post',
            data: { 'id': x, 'close': 1 },
            success: function(data) {
                if (data == 'success') alert('Pekerjaan ditutup');
            }
        })
        return;
    }
}

function goTo(x) {
    window.location = '../../DBHelper/API/SetJobID.php?job_id=' + x;
}

function goToApplicants(x) {
    window.location = '../../DBHelper/API/SetJobID.php?job_id=' + x + '&applicant=1';
}

function convertDate(x) {
    var date = new Date(x.ChangeDate);
    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    var day = date.getDate();
    var month = monthNames[date.getMonth()];
    var year = date.getFullYear();
    return String(day + ' ' + month + ' ' + year);
}

function loadStatus(x) {
    $.ajax({
        url: '../../DBHelper/API/DashboardProccess.php',
        method: 'GET',
        data: { 'status': 1, 'id': x },
        success: function(data) {
            if (data == "Open") $('tr#' + x).children('td#tooltip').children('input#open').attr('checked', true);
            else $('tr#' + x).children('td#tooltip').children('input#close').attr('checked', true);
        }
    })
}

function changeStatus(x) {
    $("tr#" + x + ">td#tooltip>input:checkbox").on('click', function() {
        var $box = $(this);
        if ($box.is(":checked")) {
            var group = "input:checkbox[name='" + $box.attr("name") + "']";
            $(group).prop("checked", false);
            $box.prop("checked", true);
            console.log($box.attr('id'));
            if ($box.attr('id') == 'open') {
                openJob(x);
            }
            if ($box.attr('id') == 'close') {
                if (confirm('konfirmasi penutupan lowongan')) {
                    $.ajax({
                        url: '../../DBHelper/API/OpenCloseJob.php',
                        method: 'post',
                        data: { 'id': x, 'close': 1 },
                        success: function(data) {
                            console.log(data);
                            if (data == 'success') alert('Pekerjaan ditutup');
                        }
                    })
                    return;
                } else {
                    $(group).prop("checked", true);
                    $box.prop("checked", false);
                }
            }
        } else {
            $box.prop("checked", true);
        }
    });
}