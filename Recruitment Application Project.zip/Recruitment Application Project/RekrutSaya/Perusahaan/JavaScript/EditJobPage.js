var id = 0;

function getCompanyLogged() {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'id': 1 },
        success: function(data) {
            id = data;
        }
    }).done(function(resp) {
        getCompanyInfo(resp);
    })
}

function getCompanyInfo(x) {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'info': 1, 'company_id': x },
        success: function(data) {
            console.log(data);
            var company = JSON.parse(data);
            if (company.ProfilePictureAddress != "") {
                var template = $('#profile_picture').clone().attr("src", company.ProfilePictureAddress).attr('style', 'width: 30px; border-radius: 50%;').show();
            } else {
                var template = $('#profile_picture').clone().attr('src', '../../assets/defaultComp.png').attr('style', 'width: 30px; border-radius: 50%;').show();
            }
            $(template).insertBefore('#username_navbar');
            var temp_con = $(template).clone().attr("style", 'width: 150px; margin-left: 100px; margin-bottom: 50px; border-radius: 50%;');
            $('#username_navbar').text(company.CompanyName);
            $('#username_content_text').text(company.CompanyName);
            $(temp_con).insertBefore('#username_content');

        }
    })
}
$(document).ready(function() {
    getCompanyLogged();
    $.ajax({
        url: '../../DBHelper/API/LoadSelect.php',
        method: 'GET',
        data: { 'type': 1 },
        success: function(data) {
            var type = JSON.parse(data);
            for (var i = 0; i < type.length; i++) {
                $('#job_type').append('<option value="' + type[i].ID + '">' + type[i].JobType + '</option>');
            }
        }
    })

    $.ajax({
        url: '../../DBHelper/API/LoadSelect.php',
        method: 'GET',
        data: { 'salary': 1 },
        success: function(data) {
            var type = JSON.parse(data);
            for (var i = 0; i < type.length; i++) {
                $('#salary').append('<option value="' + type[i].ID + '">' + type[i].salary + '</option>');
            }
        }
    })

    $.ajax({
        url: '../../DBHelper/API/LoadSelect.php',
        method: 'GET',
        data: { 'location': 1 },
        success: function(data) {
            var type = JSON.parse(data);
            for (var i = 0; i < type.length; i++) {
                $('#location').append('<option value="' + type[i].ID + '">' + type[i].Location + '</option>');
            }
        }
    })

    $('.photo').on('change', function(e) {
        var fileName = '';
        fileName = e.target.value.split('\\').pop();

        if (fileName)
            $('#input_photo').text(fileName);
    });

    var ID, JobID;

    $.ajax({
        url: '../../DBHelper/API/getIDJobID.php',
        method: 'GET',
        data: { 'ID': 1 },
        success: function(data) {
            ID = data;
        }
    }).done(function(data) {
        ID = data;
        $.ajax({
            url: '../../DBHelper/API/getIDJobID.php',
            method: 'GET',
            data: { 'JobID': 1 },
            success: function(data) {
                JobID = data;
            }
        }).done(function(data1) {
            JobID = data1;
            console.log(ID);
            console.log(JobID);
            $.ajax({
                url: '../../DBHelper/API/EditJobLoad.php',
                method: 'GET',
                data: { 'ID': ID, 'JobID': JobID, 'loadJob': 1 },
                success: function(data) {

                    console.log(data);
                    var job = JSON.parse(data);
                    var facility = job.Facility.split(", ");
                    $('#job_id').val(job.ID);
                    $('#job_name').val(job.JobName);
                    $('#job_type').val(job.JobType);
                    $('#salary').val(job.Salary);
                    $('#location').val(job.JobLocation);
                    for (var i = 0; i < facility.length; i++) {
                        $('[value="' + facility[i] + '"]').attr('checked', true);
                    }
                    $('#job_desc').val(job.Description);
                    $('#job_requirment').val(job.JobCondition);
                }
            })
        })

    })
});