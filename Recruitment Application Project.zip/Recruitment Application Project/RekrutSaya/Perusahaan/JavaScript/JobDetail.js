var id = 0;

function getCompanyLogged() {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'id': 1 },
        success: function(data) {
            id = data;
        }
    }).done(function(resp) {
        getCompanyInfo(resp);
        loadApplicants(resp);
    })
}

function getCompanyInfo(x) {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'info': 1, 'company_id': x },
        success: function(data) {
            console.log(data);
            var company = JSON.parse(data);
            if (company.ProfilePictureAddress != "") {
                var template = $('#profile_picture').clone().attr("src", company.ProfilePictureAddress).attr('style', 'width: 30px; border-radius: 50%;').show();
            } else {
                var template = $('#profile_picture').clone().attr('src', '../../assets/defaultComp.png').attr('style', 'width: 30px; border-radius: 50%;').show();
            }
            $(template).insertBefore('#username_navbar');
            var temp_con = $(template).clone().attr("style", 'width: 150px; margin-left: 100px; margin-bottom: 50px; border-radius: 50%;');
            $('#username_navbar').text(company.CompanyName);
            $('#username_content_text').text(company.CompanyName);
            $(temp_con).insertBefore('#username_content');

        }
    })
}
$(document).ready(function() {
    getCompanyLogged();
})

function acceptApplicant(x) {
    $.ajax({
        url: '../../DBHelper/API/AcceptDenyApplicants.php',
        method: 'post',
        data: { 'id': x, 'accept': 1 },
        success: function(data) {
            if (data == 'success') alert('Pelamar diterima');
        }
    })
}

function changeStatus(x) {
    $("tr#" + x + ">td#tooltip>input:checkbox").on('click', function() {
        var $box = $(this);
        if ($box.is(":checked")) {
            var group = "input:checkbox[name='" + $box.attr("name") + "']";
            $(group).prop("disabled", true);
            $box.prop("checked", true);
            console.log($box.attr('id'));
            if ($box.attr('id') == 'accept') {
                if (confirm('konfirmasi penerimaan lamaran')) {
                    acceptApplicant(x);
                } else {
                    $(group).prop("checked", false);
                    $(group).prop("disabled", false);
                }
            }
            if ($box.attr('id') == 'deny') {
                if (confirm('konfirmasi penolakan lamaran')) {
                    $.ajax({
                        url: '../../DBHelper/API/AcceptDenyApplicants.php',
                        method: 'post',
                        data: { 'id': x, 'deny': 1 },
                        success: function(data) {
                            console.log(data);
                            if (data == 'success') alert('Pelamar ditolak');
                        }
                    })
                    return;
                } else {
                    $(group).prop("checked", false);
                    $(group).prop("disabled", false);
                }
            }
        } else {
            $box.prop("checked", false);
            $(group).prop("disabled", false);
        }
    });
}

function loadApplicants(x) {
    $.ajax({
        url: '../../DBHelper/API/ApplicantsLoad.php',
        method: 'GET',
        data: { 'job': 1, 'comp_id': x },
        success: function(data) {
            if (data == 'no data') {
                var template = $('.empty').clone().show();
                $('#table_body').append(template);
                $('.empty').append('<td class="empty" colspan="4">Belum ada pelamar</td>');
            } else {
                console.log(data);
                var job = JSON.parse(data);
                var counter = 0;
                while (counter < job.length) {
                    var template = $('.job_info', '#table_template').clone().removeClass('.job_info').attr('id', job[counter].ID).data("job", job[counter]).show();
                    var date = convertDate(job[counter]);
                    $('#iNo', template).text(counter + 1);
                    $('#iApplicants', template).text(job[counter].ApplicantName);
                    $('#iDate', template).text(date);
                    var cvlocation = job[counter].CVLocation.split('/');
                    $('#tooltip #download_cv', template).attr('href', '../../DBHelper/API/download_cv.php?file=' + cvlocation[3]);
                    console.log(job[counter].ID)
                    $('#table_body').append(template);
                    loadStatus(job[counter].JobID, job[counter].ID);
                    changeStatus(job[counter].ID);

                    counter++;
                }

            }
        }
    })
}

function convertDate(x) {
    var date = new Date(x.Date);
    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    var day = date.getDate();
    var month = monthNames[date.getMonth()];
    var year = date.getFullYear();
    return String(day + ' ' + month + ' ' + year);
}


function convertDateJob(x) {
    var date = new Date(x.InputDate);
    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    var day = date.getDate();
    var month = monthNames[date.getMonth()];
    var year = date.getFullYear();
    return String(day + ' ' + month + ' ' + year);
}

function loadStatus(x, y) {
    $.ajax({
        url: '../../DBHelper/API/ApplicantsLoad.php',
        method: 'GET',
        data: { 'status': 1, 'id': x, 'applicant': y },
        success: function(data) {
            console.log(data);
            if (data == "Accept") {
                console.log('tes12');
                $('tr#' + y).children('td#tooltip').children('input#accept').attr('checked', true).attr('disabled', true);
                $('tr#' + y).children('td#tooltip').children('input:checkbox').attr('disabled', true);
            } else if (data == "Deny") {
                $('tr#' + y).children('td#tooltip').children('input#deny').attr('checked', true).attr('disabled', true);
                $('tr#' + y).children('td#tooltip').children('input:checkbox').attr('disabled', true);
            } else {
                console.log('tes');
                $('tr#' + y).children('td#tooltip').children('input#accept').attr('checked', false);
                $('tr#' + y).children('td#tooltip').children('input#deny').attr('checked', false);
                $('tr#' + y).children('td#tooltip').children('input:checkbox').attr('disabled', false);
            }
        }
    })
}

var ID, JobID, y;

$.ajax({
    url: '../../DBHelper/API/getIDJobID.php',
    method: 'GET',
    data: { 'ID': 1 },
    success: function(data) {
        ID = data;
    }
}).done(function(data) {
    ID = data;
    $.ajax({
        url: '../../DBHelper/API/getIDJobID.php',
        method: 'GET',
        data: { 'JobID': 1 },
        success: function(data) {
            JobID = data;
        }
    }).done(function(data1) {
        JobID = data1;
        console.log(ID);
        console.log(JobID);
        $.ajax({
            url: '../../DBHelper/API/EditJobLoad.php',
            method: 'GET',
            data: { 'ID': ID, 'JobID': JobID, 'loadJob': 1 },
            success: function(data) {
                console.log(data);
                var job = JSON.parse(data);
                var date = convertDateJob(job);
                var location = getLocation(job.JobLocation);
                console.log(y);
                $('h2#job_name').text(job.JobName);
                $('#input_date').text(date);
                $('#input_location').text(location);
            }
        })
    })

})

function getLocation(x) {
    var y;
    $.ajax({
        url: '../../DBHelper/API/LoadLocationName.php',
        method: 'GET',
        data: { 'location': x },
        async: false,
        success: function(data) {
            y = data;
        }
    })
    return y;
}