var id = 0;

function getCompanyLogged() {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'id': 1 },
        success: function(data) {
            id = data;
        }
    }).done(function(resp) {
        getCompanyInfo(id);
    })
}

function getCompanyInfo(x) {
    $.ajax({
        url: '../../DBHelper/API/getCompany.php',
        method: 'get',
        data: { 'info': 1, 'company_id': x },
        success: function(data) {
            var company = JSON.parse(data);
            if (company.ProfilePictureAddress != "") {
                var template = $('#profile_picture').clone().attr("src", company.ProfilePictureAddress).attr('style', 'width: 30px; border-radius: 50%;').show();
            } else {
                var template = $('#profile_picture').clone().attr('src', '../../assets/defaultComp.png').attr('style', 'width: 30px; border-radius: 50%;').show();
            }
            $(template).insertBefore('#username_navbar');
            var temp_con = $(template).clone().attr("style", 'width: 150px; margin-left: 100px; margin-bottom: 50px; border-radius: 50%;');
            $('#username_navbar').text(company.CompanyName);
            $('#username_content_text').text(company.CompanyName);
            $(temp_con).insertBefore('#username_content');

        }
    })
}
$(document).ready(function() {
    getCompanyLogged();

    function removeErrorMessage() {
        $(".error_message").empty();
    }

    function appendErrorMessage(x) {
        $(".error_message").append('<span class="error" style="color: red;">' + x + '</span><br>');
    }

    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    $("#form_signup").on('submit', function(e) {
        removeErrorMessage();


        let valid = true;
        const email = $('#email').val().toString();
        const password = $('#password').val().toString();
        const phone = $('#phone');

        if (!validateEmail(email)) {
            appendErrorMessage('Email tidak sesuai format Email');
            valid = false;
        }
        if (password.length < 8) {
            appendErrorMessage('Panjang password kurang dari 8 karakter');
            valid = false;
        }

        if (valid) {
            $(this).submit();
        } else {
            event.preventDefault();
        }
    });


});