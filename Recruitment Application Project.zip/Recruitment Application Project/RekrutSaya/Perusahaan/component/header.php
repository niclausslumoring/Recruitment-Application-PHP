<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->
<?php if (isset($_SESSION['company_id'])) {


?>
    <nav class="navbar header">

        <!-- Logo -->
        <div class="mr-auto">
            <a href="DashboardPage.php" id="brand" style="text-decoration: none;">
                <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
            </a>
        </div>

        <!-- Right Navbar Content-->
        <div class="ml-auto">
            <a href="CompEditProf.html" id="username" style="text-decoration: none; margin-right: 50px;">
                <img src="" alt="ProfilePicture" id="profile_picture" style="display: none; width: 30px; border-radius: 50%;">
                <span class="align-self-center ml-1" style="color: #f49e4c; display: inline-block;" id="username_navbar"></span>
            </a>
            <a href="./../../DBHelper/API/LogoutComp.php" id="keluar" style="text-decoration: none; margin-right: 100px;"><span>Keluar</span></a>
        </div>
    </nav>
<?php
} else {
?>
    <nav class="navbar header">
        <div class="mr-auto">
            <a href="LandingPage.php" id="brand" style="text-decoration: none;">
                <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
            </a>
        </div>

        <div class="ml-auto">
            <a href="CompSignIn.php" id="masuk" style="text-decoration: none;">
                <span class="masuk">Masuk</span>
            </a>
            <a href="../../../Pelamar/UserRegister.php" id="pelamar"><span class="pelamar" style="text-decoration: none;">Pelamar</span></a>
        </div>
    </nav>
<?php } ?>