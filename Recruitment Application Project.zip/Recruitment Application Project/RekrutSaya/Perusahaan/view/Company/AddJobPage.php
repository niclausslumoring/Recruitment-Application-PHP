<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekrut.Saya - Tambah Pekerjaan</title>

    <link rel='shortcut icon' type='image/x-icon' href='../../assets/favicon.png' />

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="../../style/style.css">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/91e6fc2cdf.js" crossorigin="anonymous"></script>

    <script src="../../JavaScript/AddJobPage.js" type="text/javascript"></script>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar header">

        <!-- Logo -->
        <div class="mr-auto">
            <a href="DashboardPage.php" id="brand" style="text-decoration: none;">
                <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
            </a>
        </div>

        <!-- Right Navbar Content-->
        <div class="ml-auto">
            <a href="CompEditProf.html" id="username" style="text-decoration: none; margin-right: 50px;">
                <img src="" alt="ProfilePicture" id="profile_picture" style="display: none; width: 30px; border-radius: 50%;">
                <span class="align-self-center ml-1" style="color: #f49e4c; display: inline-block;" id="username_navbar"></span>
            </a>
            <a href="../../DBHelper/API/LogoutComp.php" id="keluar" style="text-decoration: none; margin-right: 100px;"><span>Keluar</span></a>
        </div>
    </nav>

    <!-- Dashboard Page Content-->
    <div class="content container-fluid mb-3">
        <div class="mt-4" style="margin-left: 100px;">
            <a href="DashboardPage.php" id="back" style="text-decoration: none;  color: white;"><span class="pelamar" style="background-color: #0e79b2;">Kembali</span></a>
        </div>
        <div class="mt-3 container" style="border: 1px solid black;">
            <h2 class="mt-3 mb-3" style="color: #0e79b2; font-weight: bold;">Tambahkan pekerjaan baru</h2>
            <form action="../../DBHelper/API/AddJobProccess.php" method="POST" id="form_add_job" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-sm">
                        <div class="form-group">
                            <label for="job_name" style="color: #0e79b2;">Nama Pekerjaan<Span style="color: red;">*</Span></label>
                            <input type="text" class="form-control" name="job_name" id="job_name" placeholder="e.g. Rekrut.Saya" required>
                        </div>
                        <div class="row form-group">
                            <div class="col">
                                <select class="form-control" name="job_type" id="job_type" required>
                                    <option value="" style="display: none;">Tipe Pekerjaan*</option>
                                </select>
                            </div>
                            <div class="col">
                                <select class="form-control" name="location" id="location" required>
                                    <option value="" style="display: none;">Lokasi*</option>
                                </select>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col">
                                <select class="form-control" name="salary" id="salary" required>
                                    <option value="" style="display: none;">Gaji*</option>
                                </select>
                            </div>
                            <div class="col">
                                <span style="display: none;">tes</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="facility" style="color: #0e79b2;">Fasilitas</label>
                            <div class="row form-group">
                                <div class="col">
                                    <input type="checkbox" name="facility_check[]" id="losmen" value="Losmen"><span> </span><span> Losmen</span><br>
                                    <input type="checkbox" name="facility_check[]" id="car_borrow" value="Car Loan"><span> </span><span> Peminjaman Mobil</span><br>
                                    <input type="checkbox" name="facility_check[]" id="cafe" value="Cafe"><span> </span><span> Kafetaria</span>
                                </div>
                                <div class="col">
                                    <input type="checkbox" name="facility_check[]" id="old_day" value="Pension Plan"><span> </span><span> Jaminan Hari Tua</span><br>
                                    <input type="checkbox" name="facility_check[]" id="health" value="Health Insurance"><span> </span><span> Jaminan Kesehatan</span><br>
                                    <input type="checkbox" name="facility_check[]" id="playground" value="Playroom"><span> </span><span> Ruang Bermain</span>
                                </div>
                            </div>
                            <div class="form-group" style="margin-top: -15px;">
                                <input type="checkbox" name="facility_check[]" id="disable" value="Disability Access"><span> </span><span> Akses masuk untuk disabilitas</span><br>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="form-group">
                            <label for="photo" style="color: #0e79b2;">Foto Lingkungan Kerja (Opsional)</label><br>
                            <input type="file" name="photo" id="photo" class="photo" accept='image/*'>
                            <label for="photo" id="input_photo">Tambah Foto</label>
                        </div>
                        <div class="form-group ">
                            <label for="job_desc" style="color: #0e79b2;">Deskripsi Pekerjaan</label><br>
                            <textarea name="job_desc" id="job_desc" cols="50 " rows="3 "></textarea>
                        </div>
                        <div class="form-group ">
                            <label for="job_requirment" style="color: #0e79b2;">Persyaratan Pelamar</label><br>
                            <textarea name="job_requirment" id="job_requirment" cols="50 " rows="3 "></textarea>
                        </div>
                    </div>
                </div>
                <div class="error_message mt-1 ">
                    <span class="error " style="color: red; "></span>
                </div>
                <div class="text-center ">
                    <button type="submit" class="btn btn-primary mt-3 mb-3 " style="padding-left: 50px; padding-right: 50px; " name="add_job" id="add_job">Tambah Pekerjaan</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer container-fluid">
        <div class="row">
            <div class="col-md-5">
                <a href="../../../Pelamar/index.php" id="brand">
                    <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="company">
                    <div class="company_detail">
                        <span>Alamat : JL.KH.Syahdan,Jakarta</span><br>
                        <span>Telepon: 021-7539153</span><br>
                        <span>Email : rekrutsaya@gmail.com</span>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <a href="../../../Pelamar/index.php">Halaman Utama</a>
                <br>
                <a href="../../../Pelamar/index.php#about_us">Tentang Kami</a>
                <br>
                <a href="../../../Pelamar/FaqPage.php">FAQ</a>
                <br>
            </div>
            <div class="col-md-3">
                <a href="../../../Pelamar/DashboardPage.php">Cari Pekerjaan</a>
                <br>
                <a href="LandingPage.php">Mendaftarkan Perusahaan</a>
                <br>
            </div>
            <div class="align-self-end col-md-3" style="color: black">
                <a href="">&#9400 Rekrut.Saya 2020</a>
            </div>

        </div>

    </div>
</body>

</html>