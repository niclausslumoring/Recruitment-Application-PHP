<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekrut.Saya - Company Sign In</title>

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="../../style/CompSignIn.css">

    <link rel='shortcut icon' type='image/x-icon' href='../../assets/favicon.png' />

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>

    <script src="../../JavaScript/CompSignIn.js"></script>
</head>

<body>
    <nav class="navbar header">
        <div class="mr-auto">
            <a href="LandingPage.php" id="brand" style="text-decoration: none;">
                <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
            </a>
        </div>

        <div class="ml-auto">
            <a href="LandingPage.php" id="masuk" style="text-decoration: none;">
                <span class="masuk">Daftar</span>
            </a>
            <a href="../../../Pelamar/UserRegister.php" id="pelamar" style="text-decoration: none;"><span class="pelamar">Pelamar</span></a>
        </div>
    </nav>

    <div id="login">
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="login-form" class="form" action="../../DBHelper/API/CompSignInProccess.php" method="post">
                            <span class="Judul1"> Masuk Sebagai <span class="Judul2">Perusahaan</span></span>
                            <hr>
                            <div class="form-group">

                                <input type="email" name="email" id="email" class="form-control" placeholder="Email" <?php
                                                                                                                        session_start();
                                                                                                                        if (isset($_SESSION['password'])) {
                                                                                                                            echo 'value="' . $_SESSION['insert_email'] . '"';
                                                                                                                        } ?> required>
                            </div>
                            <div class="form-group">

                                <input type="password" name="password" id="password" class="form-control" placeholder="Kata Sandi" required>
                            </div>
                            <div class="form-group">
                                <input id="remember_me" name="remember_me" type="checkbox"> <label for="remember_me" class="text-info"><span>Ingat Saya</span> <span></span></label><br>
                                <input type="submit" name="submit" id="submit" class="btn btn-info btn-md" value="submit">
                                <div class="error_message mt-1">
                                    <span class="error" style="color: red; ">
                                        <?php
                                        if (isset($_SESSION['email'])) {
                                            echo 'Email tidak terdaftar';
                                        } else if (isset($_SESSION['password'])) {
                                            echo 'Password salah';
                                        } ?>
                                    </span>
                                </div>
                            </div>
                            <div id="register-link" class="text-right">
                                <a href="ForgotPassword.html" class="text-info">Lupa Kata Sandi?</a>
                            </div>
                        </form>
                        <?php
                        if (isset($_SESSION['email'])) {
                            if (basename($_SERVER['PHP_SELF']) != $_SESSION['email']) {
                                session_unset();
                                session_destroy();
                            }
                        }
                        if (isset($_SESSION['password'])) {
                            if (basename($_SERVER['PHP_SELF']) != $_SESSION['password']) {
                                session_unset();
                                session_destroy();
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br>
    <br>
    <br>
    <br>


    <!-- Footer -->
    <div class="footer container-fluid">
        <div class="row">
            <div class="col-md-5">
                <a href="../../../Pelamar/index.php" id="brand">
                    <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="company">
                    <div class="company_detail">
                        <span>Alamat : JL.KH.Syahdan,Jakarta</span><br>
                        <span>Telepon: 021-7539153</span><br>
                        <span>Email : rekrutsaya@gmail.com</span>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <a href="../../../Pelamar/index.php">Halaman Utama</a>
                <br>
                <a href="../../../Pelamar/index.php#about_us">Tentang Kami</a>
                <br>
                <a href="../../../Pelamar/FaqPage.php">FAQ</a>
                <br>
            </div>
            <div class="col-md-3">
                <a href="../../../Pelamar/index.php#search_job">Cari Pekerjaan</a>
                <br>
                <a href="LandingPage.php">Mendaftarkan Perusahaan</a>
                <br>
            </div>
            <div class="align-self-end col-md-3" style="color: black">
                <a href="">&#9400 Rekrut.Saya 2020</a>
            </div>

        </div>

    </div>


</html>

</body>

</html>