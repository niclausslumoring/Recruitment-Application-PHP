<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekrut.Saya - Dashboard</title>

    <link rel='shortcut icon' type='image/x-icon' href='../../assets/favicon.png' />

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="../../style/style.css">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://kit.fontawesome.com/91e6fc2cdf.js" crossorigin="anonymous"></script>

    <script src="../../JavaScript/DashboardPage.js"></script>
</head>

<body>

    <!-- Navbar -->
    <?php
    include_once('../../component/header.php');
    ?>

    <!-- Dashboard Page Content-->
    <div class="content container-fluid mb-4">
        <div>
            <img src="" alt="ProfilePicture" id="profile_picture" style="display: none;">
            <div class="profile mt-5 ml-4" style="display: inline-block;" id="username_content">
                <span class="align-self-center" style="color: #0e79b2; font-size: 30px;" id="username_content_text"></span><br><br>
                <a href="CompEditProf.html" id="edit_profile" style="text-decoration: none;  color: white;"><span class="pelamar" style="background-color: #f49e4c;">Ubah Profile</span></a>
            </div>
            <div class="d-flex justify-content-end">
                <a href="AddJobPage.php" id="add_job" style="text-decoration: none; color: white;margin-top: -75px; margin-right: 100px;"><span class="pelamar" style="background-color: #f49e4c;">Tambah Lowongan</span></a>
            </div>
        </div>

        <div class="jobs container" style="margin-top: -10px">
            <h2 class="mb-2 mt-2" style="color: #0e79b2; font-weight: bold;">Daftar pekerjaan yang sudah ditambahkan</h2>
            <table class="table table-striped table-bordered text-center">
                <thead>
                    <tr style="background-color: #0e79b2;">
                        <td scope="col">No</td>
                        <td scope="col">Nama Pekerjaan</td>
                        <td scope="col">Tanggal Terakhir Diubah</td>
                        <td scope="col">Status</td>
                    </tr>
                </thead>
                <tbody id="table_body">
                </tbody>
            </table>
            <table id="table_template">
                <tr class="job_info" style="display: none">
                    <th scope="row" style="vertical-align: middle;" id="iNo"></th>
                    <td style="vertical-align: middle;" id="iJobName"></td>
                    <td style="vertical-align: middle;" id="iDate"></td>
                    <td id="tooltip">
                        <input type="checkbox" name="status" id="open" value="Open"> <span>Buka</span><br>
                        <input type="checkbox" name="status" id="close" class="mb-3" value="Close"> <span>Tutup</span><br>
                        <a style="text-decoration: none; color: white;cursor: pointer;" id="applicants"><span class="pelamar" style="background-color: #f49e4c; padding-left: 10px; padding-right: 10px; display: inline-block;">Lihat Pelamar</span></a><br>
                        <a style="text-decoration: none; color: white; cursor: pointer;" id="edit_job"><span class="pelamar" style="background-color: #0e79b2; padding-left: 10px; padding-right: 10px;display: inline-block; margin-top: 5px; ">Ubah</span></a>
                    </td>
                </tr>
                <tr class="empty" style="display: none">
                </tr>
            </table>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer container-fluid">
        <div class="row">
            <div class="col-md-5">
                <a href="../../../Pelamar/index.php" id="brand">
                    <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="company">
                    <div class="company_detail">
                        <span>Alamat : JL.KH.Syahdan,Jakarta</span><br>
                        <span>Telepon: 021-7539153</span><br>
                        <span>Email : rekrutsaya@gmail.com</span>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <a href="../../../Pelamar/index.php">Halaman Utama</a>
                <br>
                <a href="../../../Pelamar/index.php#about_us">Tentang Kami</a>
                <br>
                <a href="../../../Pelamar/FaqPage.php">FAQ</a>
                <br>
            </div>
            <div class="col-md-3">
                <a href="../../../Pelamar/index.php#search_job">Cari Pekerjaan</a>
                <br>
                <a href="LandingPage.php">Mendaftarkan Perusahaan</a>
                <br>
            </div>
            <div class="align-self-end col-md-3" style="color: black">
                <a href="">&#9400 Rekrut.Saya 2020</a>
            </div>

        </div>

    </div>


</body>

</html>