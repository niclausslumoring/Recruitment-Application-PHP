<!--
    Created by : Muhammad Wira Nugraha
    Date : 1 February 2020
-->

<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekrut.Saya</title>

    <!-- Adding Favicon -->
    <link rel='shortcut icon' type='image/x-icon' href='../../assets/favicon.png' />

    <!-- Self Style by Muhammad Wira -->
    <link rel="stylesheet" href="../../style/style.css">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="../../JavaScript/LandingPage.js" type="text/javascript"></script>
</head>

<body>

    <!-- Navbar -->
    <?php
    include_once('../../component/header.php');
    ?>

    <!-- Landing Page Content-->
    <div class="content container-fluid">
        <div class="row">
            <div class="col-sm">
                <div class="mt-5 mr-auto" id="left_content">
                    <h2 style="color: #0e79b2; font-weight: bold;">Daftarkan perusahaan Anda</h2>
                    <div class="daftar" style="background-color: #ffe7d1; padding: 20px; color: #0e79b2; font-weight: bold; border-radius: 10px;">
                        <form action="../../DBHelper/API/RegisterProccess.php" method="post" id="form_signup">
                            <div class="form-group">
                                <label for="company_name">Nama Perusahaan<Span style="color: red;">*</Span></label>
                                <input type="text" class="form-control" name="company_name" id="company_name" placeholder="e.g. Rekrut.Saya" required>
                            </div>
                            <div class="form-group">
                                <label for="Email">Email Perusahaan<Span style="color: red;">*</Span></label>
                                <input type="email" class="form-control" name="email" id="email" placeholder="rekrutsaya@gmail.com" required>
                            </div>
                            <div class="form-group">
                                <label for="address">Alamat Perusahaan<Span style="color: red;">*</Span></label>
                                <input type="text" class="form-control" name="address" id="address" placeholder="e.g. JL.KH. Syahdan" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Nomor Telepon Perusahaan<Span style="color: red;">*</Span></label>
                                <input type="tel" class="form-control" name="phone" id="phone" placeholder="e.g. 08123456789" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password<Span style="color: red;">*</Span></label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="e.g. a1b2c3" required>
                                <span>
                                    <ul>
                                        <li>Password harus memiliki paling tidak 8 karakter</li>
                                    </ul>
                                </span>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary mt-3" style="padding-left: 50px; padding-right: 50px;" name="register">Daftar</button>
                            </div>
                        </form>
                        <div class="error_message mt-1">
                            <span class="error" style="color: red;"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-auto">
                <div style="width: 1px; background-color: black; height: 700px;"></div>
            </div>
            <div class="col-sm">
                <div class="mt-5 ml-auto" id="right_content">
                    <h2 style="color: #0e79b2; font-weight: bold;">Mengapa perlu mendaftarkan perusahaan Anda di Rekrut.<span style="color: #f49e4c;">Saya</span> ?</h2>
                    <div style="color: #0e79b2; font-weight: bold; margin-top: 50px;">
                        <div>
                            <img src="../../assets/terbaik.png" alt="star.png" style="width: 75px; display: inline-block;">
                            <h4 style="display: inline-block; margin-left: 5px;">Mendapatkan pelamar terbaik</h4>
                        </div>
                        <div style="margin-top: 10px;">
                            <img src="../../assets/mudah.png" alt="star.png" style="width: 80px; display: inline-block;">
                            <h4 style="display: inline-block; margin-left: 5px;">Mempermudah proses rekrut</h4>
                        </div>
                        <div style="margin-top: 10px;">
                            <img src="../../assets/bantuan.png" alt="star.png" style="width: 75px; display: inline-block;">
                            <h4 style="display: inline-block; margin-left: 5px;">Adanya bantuan dalam proses merekrut</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer container-fluid">
        <div class="row">
            <div class="col-md-5">
                <a href="../../../Pelamar/index.php" id="brand">
                    <span class="logoP">Rekrut.<span class="logoS">Saya</span></span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="company">
                    <div class="company_detail">
                        <span>Alamat : JL.KH.Syahdan,Jakarta</span><br>
                        <span>Telepon: 021-7539153</span><br>
                        <span>Email  : rekrutsaya@gmail.com</span>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <a href="../../../Pelamar/index.php">Halaman Utama</a>
                <br>
                <a href="../../../Pelamar/index.php#about_us">Tentang Kami</a>
                <br>
                <a href="../../../Pelamar/FaqPage.php">FAQ</a>
                <br>
            </div>
            <div class="col-md-3">
                <a href="../../../Pelamar/index.php#search_job">Cari Pekerjaan</a>
                <br>
                <a href="LandingPage.php">Mendaftarkan Perusahaan</a>
                <br>
            </div>
            <div class="align-self-end col-md-3" style="color: black">
                <a href="">&#9400 Rekrut.Saya 2020</a>
            </div>

        </div>

    </div>
</body>

</html>