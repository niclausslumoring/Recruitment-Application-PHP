-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2020 at 03:29 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rekrutsaya`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `ID` int(11) NOT NULL,
  `ApplicantID` int(11) NOT NULL,
  `ApplicantName` varchar(100) NOT NULL,
  `JobID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `CVLocation` varchar(100) NOT NULL,
  `Status` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`ID`, `ApplicantID`, `ApplicantName`, `JobID`, `Date`, `CVLocation`, `Status`) VALUES
(1, 4, 'John Doe', 1, '2020-02-03', '', 'Accept'),
(2, 5, 'Wira', 3, '2020-02-08', '', 'Accept'),
(3, 3, 'MactavishH6', 2, '2020-02-07', '', 'Deny'),
(4, 3, 'MactavishH6', 1, '2020-02-09', '../assets/CV/3,MactavishH6,1.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `ID` int(11) NOT NULL,
  `CompanyName` varchar(100) NOT NULL,
  `CompanyEmail` varchar(100) NOT NULL,
  `CompanyAddress` varchar(100) NOT NULL,
  `CompanyPhone` varchar(13) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `ProfilePictureAddress` varchar(100) NOT NULL,
  `CompanyDesc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`ID`, `CompanyName`, `CompanyEmail`, `CompanyAddress`, `CompanyPhone`, `Password`, `ProfilePictureAddress`, `CompanyDesc`) VALUES
(1, 'Muhammad.Co', 'cpt.wiranugraha47@gmail.com', 'JL. Puyuh XI Blok F 341', '081385847347', '$2y$10$rbsobNwFIdcBdIXnRgQDc.ErOPdYOLk.uTJHhjvp8QijgTQO2BVaC', '../../assets/ProfilePicture/Hina_Amano_New (2019_10_04 04_38_15 UTC).jpg', 'testestes'),
(2, 'RekrutSaya', 'saya@gmail.com', 'JL. Puyuh XI Blok F 341', '081385847347', '$2y$10$5Pms0JyeROXCtD8JLYrghONi45Q7YKE/b0LxWIHj93kXuPT9ituSS', '', ''),
(3, 'Nugraha.Co', 'abiyokowd@gmail.com', 'JL. Anggrek', '021803485', '$2y$10$Qy7S6gLakrmCNqyJFDq75.0q8qVDsQJKjV.Ims205do2lJwjNgl7q', '', ''),
(4, 'Samsung', 'niclausslumoring97@gmail.com', 'Palem', '081299134066', '$2y$10$myl5PM85GdsHF7H.XPTSf.Ypy0E5cdFPVu3m/II9SwqZBG9prHToe', '', ''),
(5, 'Iphone', 'niclausslumoring97@gmail.com', 'Palem', '081299134066', '$2y$10$xeDo.5mB0MIY0glpeVFJXelmJpbXUfFN9Oj1r.Ow84HpejRrBfgUe', '', ''),
(6, 'Nokia', 'niclausslumoring97@gmail.com', 'Palem', '081299134066', '$2y$10$CtRGTEypGALb9.1cyEBw5eas4ziFk4fMcXf96xKAlR8xbi7fuEwyG', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `ID` int(11) NOT NULL,
  `CompanyID` int(11) NOT NULL,
  `JobName` varchar(100) NOT NULL,
  `InputDate` date NOT NULL,
  `ChangeDate` date NOT NULL,
  `JobLocation` int(11) NOT NULL,
  `JobType` int(11) NOT NULL,
  `Salary` int(11) NOT NULL,
  `Status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`ID`, `CompanyID`, `JobName`, `InputDate`, `ChangeDate`, `JobLocation`, `JobType`, `Salary`, `Status`) VALUES
(1, 1, 'Tes', '2020-02-06', '2020-02-09', 1, 1, 2, 'Open'),
(2, 1, 'Tes2', '2020-02-06', '2020-02-07', 14, 2, 2, 'Open'),
(3, 3, 'Barista', '2020-02-08', '2020-02-08', 9, 1, 1, 'Open'),
(4, 2, 'Pelayan', '2020-02-08', '2020-02-08', 10, 1, 1, 'Open'),
(5, 6, 'kasir', '2020-02-09', '2020-02-09', 10, 1, 2, 'Open');

-- --------------------------------------------------------

--
-- Table structure for table `jobdetail`
--

CREATE TABLE `jobdetail` (
  `ID` int(11) NOT NULL,
  `Facility` varchar(100) NOT NULL,
  `Photo` varchar(100) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `JobCondition` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobdetail`
--

INSERT INTO `jobdetail` (`ID`, `Facility`, `Photo`, `Description`, `JobCondition`) VALUES
(1, 'Losmen, Cafe, Playroom', '../../assets/JobPlace/hinaa (2019_10_04 04_38_15 UTC).jpg', 'tes', 'testestestes'),
(2, 'Pension Plan, Health Insurance, Playroom', '', 'res', 'res'),
(3, 'Disability Access', '', 'Membuat kopi terenak dan melayani pelanggan dengan sopan dan baik', 'Pria atau Wanita umur 18 tahun keatas,\r\nPendidikan terakhir SMA,\r\nPekerja Keras'),
(4, '', '', 'asdasd', 'asdasd'),
(5, 'Car Loan', '', 'bagus', 'cantik');

-- --------------------------------------------------------

--
-- Table structure for table `jobtype`
--

CREATE TABLE `jobtype` (
  `ID` int(11) NOT NULL,
  `JobType` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobtype`
--

INSERT INTO `jobtype` (`ID`, `JobType`) VALUES
(1, 'Part Time'),
(2, 'Internship'),
(3, 'Full Time'),
(4, 'Freelancer');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `ID` int(11) NOT NULL,
  `Location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`ID`, `Location`) VALUES
(1, 'Aceh'),
(2, 'Bali'),
(3, 'Bangka Belitung'),
(4, 'Banten'),
(5, 'Bengkulu'),
(6, 'Gorontalo'),
(7, 'Jakarta Utara'),
(8, 'Jakarta Selatan'),
(9, 'Jakarta Timur'),
(10, 'Jakarta Barat'),
(11, 'Jakarta Pusat'),
(12, 'Jambi'),
(13, 'Jawa Barat'),
(14, 'Jawa Timur'),
(15, 'Kalimantan Barat'),
(16, 'Kalimantan Selatan'),
(17, 'Kalimantan Tengah'),
(18, 'Kalimantan Timur'),
(19, 'Kalimantan Utara'),
(20, 'Kepulauan Riau'),
(21, 'Lampung'),
(22, 'Maluku'),
(23, 'NTT'),
(24, 'NTB'),
(25, 'Papua'),
(26, 'Riau'),
(27, 'Sulawesi Selatan'),
(28, 'Sulawesi Tengah'),
(29, 'Sulawesi Tenggara'),
(30, 'Sulawesi Utara'),
(31, 'Sumatra Barat'),
(32, 'Sumatra Selatan'),
(33, 'Sumatra Utara'),
(34, 'Yogyakarta');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `ID` int(11) NOT NULL,
  `salary` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`ID`, `salary`) VALUES
(1, '< Rp. 1.000.000'),
(2, 'Rp. 1.000.001 - Rp. 2.000.000'),
(3, 'Rp. 2.000.001 - Rp. 3.000.000'),
(4, 'Rp. 3.000.001 - Rp. 4.000.000'),
(5, 'Rp. 4.000.001 - Rp. 5.000.000'),
(6, 'Rp. 5.000.001 >');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(225) NOT NULL,
  `email` varchar(50) NOT NULL,
  `day` varchar(5) NOT NULL,
  `month` varchar(20) NOT NULL,
  `year` varchar(10) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `handphone` varchar(15) NOT NULL,
  `password` varchar(225) NOT NULL,
  `img` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `day`, `month`, `year`, `gender`, `handphone`, `password`, `img`) VALUES
(1, 'test', 'test@gmail.co', '5', 'Februari', '1990', 'Laki - laki', '081226181117', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', NULL),
(2, 'waow', 'waw@gmail.com', '6', 'Agustus', '1990', 'Perempuan', '082198197318', 'b96c8d2b9b01bb4690de6e82a2d9791a1637213b', '8profile'),
(3, 'MactavishH6', 'cpt.wiranugraha47@gmail.com', '2', 'Oktober', '2000', 'Laki - laki', '081807575050', '7c222fb2927d828af22f592134e8932480637c0d', NULL),
(4, 'niclauss', 'niclausslumoring97@gmail.com', '8', 'Februari', '1993', 'Laki - laki', '08123131312', '7c222fb2927d828af22f592134e8932480637c0d', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fksalary` (`Salary`),
  ADD KEY `fktype` (`JobType`),
  ADD KEY `fklocation` (`JobLocation`),
  ADD KEY `fkcompany` (`CompanyID`);

--
-- Indexes for table `jobdetail`
--
ALTER TABLE `jobdetail`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `jobtype`
--
ALTER TABLE `jobtype`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applicants`
--
ALTER TABLE `applicants`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jobdetail`
--
ALTER TABLE `jobdetail`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jobtype`
--
ALTER TABLE `jobtype`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `job`
--
ALTER TABLE `job`
  ADD CONSTRAINT `fkcompany` FOREIGN KEY (`CompanyID`) REFERENCES `company` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fklocation` FOREIGN KEY (`JobLocation`) REFERENCES `location` (`ID`),
  ADD CONSTRAINT `fksalary` FOREIGN KEY (`Salary`) REFERENCES `salary` (`ID`),
  ADD CONSTRAINT `fktype` FOREIGN KEY (`JobType`) REFERENCES `jobtype` (`ID`);

--
-- Constraints for table `jobdetail`
--
ALTER TABLE `jobdetail`
  ADD CONSTRAINT `fkjobid` FOREIGN KEY (`ID`) REFERENCES `job` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
